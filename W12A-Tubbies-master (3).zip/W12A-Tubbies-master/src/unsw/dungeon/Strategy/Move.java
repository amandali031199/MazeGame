package unsw.dungeon.Strategy;

import javafx.beans.property.IntegerProperty;
import unsw.dungeon.Dungeon;
/**
 * move strategy for enemy
 * @author yinhuey
 *
 */
public interface Move {

	
	public void move(int x, int y, Dungeon dungeon,IntegerProperty posx,IntegerProperty posy,int px,int py);

}

