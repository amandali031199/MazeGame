package unsw.dungeon.Strategy;

import javafx.beans.property.IntegerProperty;
import unsw.dungeon.*;

/**
 * enemy's strategy to move away from player once player has potion
 * @author yinhuey
 *
 */
public class MoveAway implements Move{

	@Override
	public void move(int x, int y,Dungeon dungeon,IntegerProperty x2,IntegerProperty y2,int px,int py) {
		// TODO Auto-generated method stub
		// move right
        if (!moveRight(x,y,dungeon,x2,y2,px,py)) {
        	if (!moveLeft(x,y,dungeon,x2,y2,px,py)) {
        		if (!moveUp(x,y,dungeon,x2,y2,px,py)) {
        			moveDown(x,y,dungeon,x2,y2,px,py);
        		} else {
        			moveUp(x,y,dungeon,x2,y2,px,py);
        		}
        	} else {
        		moveLeft(x,y,dungeon,x2,y2,px,py);
        	}
        } else {
        	moveRight(x,y,dungeon,x2,y2,px,py);
        }

	}

	public boolean moveRight(int x, int y,Dungeon dungeon,IntegerProperty posx,IntegerProperty posy,int px,int py) {
		 if (x < dungeon.getWidth() - 1
		     && dungeon.CanMove(x+1,y) 
		     && px < x ) {
		     posx.set((x) + 1);
		     return true;
	     } 
		 return false;
	}
	
	public boolean moveUp(int x, int y,Dungeon dungeon,IntegerProperty posx,IntegerProperty posy,int px,int py) {
		 if ((y > 0) && dungeon.CanMove(x,(y-1))
				 && py > y) {
	            posy.set(y - 1);
		     return true;
	     } 
		 return false;
		 
	}
	
	public boolean moveDown(int x, int y,Dungeon dungeon,IntegerProperty posx,IntegerProperty posy,int px,int py) {
		 if (y < dungeon.getHeight() - 1 && dungeon.CanMove(x,(y+1))
			&& py < y) {
	         posy.set(y + 1);
		     return true;
	     } 
		 return false;
		 
	}
	
	public boolean moveLeft(int x, int y,Dungeon dungeon,IntegerProperty posx,IntegerProperty posy,int px,int py) {
		 if (x > 0 && dungeon.CanMove(x-1,y)
		    && px > x) {
		     posx.set((x) - 1);
		     return true;
	     } 
		 return false;
	}
	

}
