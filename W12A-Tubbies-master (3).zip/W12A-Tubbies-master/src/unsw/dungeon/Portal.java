package unsw.dungeon;

public class Portal extends Entity {
	private int id;
	private Dungeon dungeon;


    public Portal(Dungeon dungeon, int x, int y, int id) {
        super(x, y);
        this.id = id;
        this.dungeon = dungeon;
    }


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
    
    
}
