package unsw.dungeon.Frontend;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import unsw.dungeon.*;
/**
 * A DungeonLoader that also creates the necessary ImageViews for the UI,
 * connects them via listeners to the model, and creates a controller.
 * @author Robert Clifton-Everest
 *
 */
public class DungeonControllerLoader extends DungeonLoader {

    private List<ImageView> entities;

    //Images
    private Image playerImage;
    private Image wallImage;
    private Image boulderImage;
    private Image switchImage;
    private Image swordImage;
    private Image enemyImage;
    private Image enemy2Image;
    private Image treasureImage;
    private Image potionImage;
    private Image portalImage;
    private Image keyImage;
    private Image doorImage;
    private Image unlockedImage;
    private Image exitImage;
    private Image fireImage;
    private Image livesImage;
    private int i;
    private Image slimeImage;

    HashMap<Entity, Node> hashes = new  HashMap<Entity, Node> ();



    public DungeonControllerLoader(String filename)
            throws FileNotFoundException {
        super(filename);
        entities = new ArrayList<>();
        playerImage = new Image("/human_new.png");
        wallImage = new Image("/wall.jpeg");
        boulderImage = new Image("/boulder.png");
        switchImage = new Image("/pressure_plate.png");
        swordImage = new Image("/greatsword_1_new.png");
        enemyImage = new Image("/gnome.png");
        enemy2Image = new Image("/deep_elf_master_archer.png");
        treasureImage = new Image("/gold_pile.png");
        potionImage = new Image("/brilliant_blue_new.png");
        portalImage = new Image("/portal.png");
        keyImage = new Image("/key.png");
        doorImage = new Image("/closed_door.png");
        exitImage = new Image("/exit.png");
        fireImage = new Image("/fire.gif");
        livesImage = new Image("/jacket.png");
        unlockedImage = new Image("/open_door.png");
        slimeImage = new Image("/slime.jpeg");
        
    }

    @Override
    public void onLoad(Entity player) {
        ImageView view = new ImageView(playerImage);
        addEntity(player, view);
    }
    
    @Override
    public void onLoadUnlock(Door door) {
        ImageView view = new ImageView(unlockedImage);
        addEntity(door, view);
    }
    
    @Override
    public void onLoad(Slime slime) {
        ImageView view = new ImageView(slimeImage);
        view.setFitHeight(32);
        view.setFitWidth(32);
        addEntity(slime, view);
    }

    @Override
    public void onLoad(Wall wall) {
        ImageView view = new ImageView(wallImage);
        view.setFitHeight(32);
        view.setFitWidth(32);
        addEntity(wall, view);
    }
    
	
    private void addEntity(Entity entity, ImageView view) {
        trackPosition(entity, view);
        entities.add(view);
    }

    /**
     * Set a node in a GridPane to have its position track the position of an
     * entity in the dungeon.
     *
     * By connecting the model with the view in this way, the model requires no
     * knowledge of the view and changes to the position of entities in the
     * model will automatically be reflected in the view.
     * @param entity
     * @param node
     */
   
    private void trackPosition(Entity entity, Node node) {
        GridPane.setColumnIndex(node, entity.getX());
        GridPane.setRowIndex(node, entity.getY());
        entity.x().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
                GridPane.setColumnIndex(node, newValue.intValue());
            }
        });
        entity.y().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
                GridPane.setRowIndex(node, newValue.intValue());
            }
        });

        // Add keys and values (Country, City)
        hashes.put(entity, node);
     
    }

    /**
     * Create a controller that can be attached to the DungeonView with all the
     * loaded entities.
     * @return
     * @throws FileNotFoundException
     */
    public DungeonController loadController(int levelnum,Stage stage) throws FileNotFoundException {
    	Dungeon dg = load(this,levelnum);
    	DungeonController d = new DungeonController(dg, entities,hashes,stage);
    	dg.setController(d);
        return d;
    }

	@Override
	public void onLoad(Boulder boulder) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(boulderImage);
        addEntity(boulder, view);
		
	}

	@Override
	public void onLoad(FloorSwitch floorSwitch) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(switchImage);
        addEntity(floorSwitch, view);
		
	}

	@Override
	public void onLoad(Sword sword) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(swordImage);
        addEntity(sword, view);
		
	}

	@Override
	public void onLoad(Enemy enemy) {
		// TODO Auto-generated method stub
		if (i/2 == 0) {
			ImageView view = new ImageView(enemyImage);
			addEntity(enemy, view);
			i++;
		} else {
			ImageView view = new ImageView(enemy2Image);
			addEntity(enemy, view);
			i++;
		}

	}

	@Override
	public void onLoad(Treasure treasure) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(treasureImage);
        addEntity(treasure, view);
		
	}

	@Override
	public void onLoad(Potion potion) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(potionImage);
        addEntity(potion, view);
		
	}

	@Override
	public void onLoad(Portal portal) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(portalImage);
        addEntity(portal, view);
	}

	@Override
	public void onLoad(Key key) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(keyImage);
        addEntity(key, view);
		
	}

	@Override
	public void onLoad(Door door) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(doorImage);
        addEntity(door, view);
		
	}

	@Override
	public void onLoad(Exit exit) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(exitImage);
        addEntity(exit, view);
		
	}
	
	@Override
	public void onLoad(Fire fire) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(fireImage);
        addEntity(fire, view);
		
	}
	
	@Override
	public void onLoad(Lives lives) {
		// TODO Auto-generated method stub
        ImageView view = new ImageView(livesImage);
        addEntity(lives, view);
		
	}


}
