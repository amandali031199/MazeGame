package unsw.dungeon.Frontend;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.EnemiesGoal;
import unsw.dungeon.Goals.ExitGoal;
import unsw.dungeon.Goals.SwitchGoal;
import unsw.dungeon.Goals.TreasureGoal;
import unsw.dungeon.*;

/**
 * Loads a dungeon from a .json file.
 *
 * By extending this class, a subclass can hook into entity creation. This is
 * useful for creating UI elements with corresponding entities.
 *
 * @author Robert Clifton-Everest
 *
 */
public abstract class DungeonLoader {

    private JSONObject json;

    public DungeonLoader(String filename) throws FileNotFoundException {
        json = new JSONObject(new JSONTokener(new FileReader("dungeons/" + filename)));
    }

    /**
     * Parses the JSON to create a dungeon.
     * @return
     */
    public Dungeon load(DungeonControllerLoader d,int levelnum) {
        int width = json.getInt("width");
        int height = json.getInt("height");
        Dungeon dungeon = new Dungeon(width, height);
        EnemiesGoal e = new EnemiesGoal();
        SwitchGoal sw = new SwitchGoal();
        TreasureGoal t = new TreasureGoal();
        ExitGoal x = new ExitGoal();
       
        Level level = null;
        if (levelnum == 1) level = new Level(dungeon,x,false);
        else if (levelnum == 2) level = new Level(dungeon,sw,false);
        else if (levelnum == 3) level = new Level(dungeon,t,false);
        else if (levelnum == 4) level = new Level(dungeon,e,false);
        else if (levelnum == 5) {
        	ComplexGoal c = new ComplexGoal("or");
            c.addGoal(sw);
            c.addGoal(x); 
        	level = new Level(dungeon,c,true);
        } else if (levelnum == 6) {
        	ComplexGoal c = new ComplexGoal("and");
            c.addGoal(e);
            c.addGoal(t); 
        	level = new Level(dungeon,c,true);
        } else if (levelnum == 7) {
        	ComplexGoal c = new ComplexGoal("and");
            c.addGoal(t);
            c.addGoal(sw); 
            ComplexGoal c2 = new ComplexGoal("or");
            c2.addGoal(e);
            c2.addGoal(c);
        	level = new Level(dungeon,c2,true);
        } else if (levelnum == 8) {
        	ComplexGoal c = new ComplexGoal("and");
            c.addGoal(sw);
            c.addGoal(x); 
            c.addGoal(e);
            c.addGoal(t);
        	level = new Level(dungeon,c,true);
        }
        dungeon.setLevel(level);
        JSONArray jsonEntities = json.getJSONArray("entities");

        for (int i = 0; i < jsonEntities.length(); i++) {
            loadEntity(dungeon, jsonEntities.getJSONObject(i));
        }
        dungeon.initObservers();
        return dungeon;
    }

    private void loadEntity(Dungeon dungeon, JSONObject json) {
        String type = json.getString("type");
        int x = json.getInt("x");
        int y = json.getInt("y");
        Entity entity = null;
        switch (type) {
        case "player":
            Player player = new Player(dungeon, x, y);
            dungeon.setPlayer(player);
            onLoad(player);
            entity = player;
            break;
        case "wall":
            Wall wall = new Wall(x, y);
            onLoad(wall);
            entity = wall;
            break;
        // TODO Handle other possible entities
        case "boulder":
        	Boulder boulder = new Boulder(dungeon, x, y);
        	onLoad(boulder);
        	entity = boulder;
        	break;
        case "switch":
        	FloorSwitch floorSwitch = new FloorSwitch(dungeon, x, y);
        	onLoad(floorSwitch);
        	entity = floorSwitch;
        	break;
        case "sword":
        	Sword sword = new Sword(dungeon, x, y);
        	onLoad(sword);
        	entity = sword;
        	break;
        case "enemy": 
        	Player p = dungeon.getPlayer();
        	Enemy enemy = new Enemy(dungeon, x, y,p);
        	onLoad(enemy);
        	entity = enemy;
        	break;
        case "treasure":
        	Treasure treasure = new Treasure(dungeon, x, y);
        	onLoad(treasure);
        	entity = treasure;
        	break;
        case "invincibility":
        	Potion potion = new Potion(dungeon, x, y);
        	onLoad(potion);
        	entity = potion;
        	break;
        case "portal":
        	int id = json.getInt("id");
        	Portal portal = new Portal(dungeon,x,y, id);
        	onLoad(portal);
        	entity = portal;
        	break;
        case "key":
        	id = json.getInt("id");
        	Key key = new Key(dungeon, x, y, id);
        	onLoad(key);
        	entity = key;
        	break;
        case "door":
        	id = json.getInt("id");
        	Door door = new Door(dungeon, x, y, id);
        	onLoad(door);
        	entity = door;
        	break;
        case "exit":
        	Exit exit = new Exit(dungeon,x, y);
        	onLoad(exit);
        	entity = exit;
        	break;
        case "life":
        	Lives lives = new Lives(dungeon,x,y);
        	onLoad(lives);
        	entity = lives;
        	break;
        case "fire":
        	Fire fire = new Fire(dungeon,x,y);
        	onLoad(fire);
        	entity = fire;
        	break;
        case "slime":
        	Slime slime = new Slime(x,y);
        	onLoad(slime);
        	entity = slime;
        }
        
        dungeon.addEntity(entity);
        dungeon.recordEntity(entity);

    }

    public abstract void onLoad(Entity player);

    public abstract void onLoad(Wall wall);
    
    public abstract void onLoad(Slime slime);

    
    public abstract void onLoad(Boulder boulder);
    
    public abstract void onLoad(FloorSwitch floorSwitch);
    
    public abstract void onLoad(Sword sword);

    public abstract void onLoad(Enemy enemy);

    public abstract void onLoad(Treasure treasure);
    
    public abstract void onLoad(Potion potion);
    
    public abstract void onLoad(Portal portal);
    
    public abstract void onLoad(Key key);
    
    public abstract void onLoad(Door door);
    
    public abstract void onLoad(Exit exit);
    
    public abstract void onLoad(Lives lives);

    public abstract void onLoad(Fire fire);

    public abstract void onLoadUnlock(Door door);


    // TODO Create additional abstract methods for the other entities

}
