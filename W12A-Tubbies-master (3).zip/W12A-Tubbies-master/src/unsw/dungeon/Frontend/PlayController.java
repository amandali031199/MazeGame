package unsw.dungeon.Frontend;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import unsw.dungeon.DungeonApplication;

public class PlayController {
     Stage stage;
     int level;
	 public PlayController(Stage primaryStage,int num) {
		stage = primaryStage;
		level = num;
	}
	
	@FXML
    private Pane pane;

	@FXML
	private Button play;
	
	@FXML
	private Text instruction;

	
	@FXML
	private Text goaltext;
	
	@FXML
	private Text entity1;
	
	@FXML
	private Text entity2;
	
	
	@FXML
	private Text exp;
	
	@FXML
	private Text exp2;
	
	@FXML
	private Text exp3;
	
	@FXML
	private Text goaltitle;
	
    @FXML
    void playOnAction(ActionEvent event) throws IOException {
    	DungeonApplication a = new DungeonApplication();
    	a.DungeonScene(stage,level);
    	
    }
    
    @FXML
    public void initialize() {
    	instruction.setFill(Color.YELLOW);
    	goaltitle.setFill(Color.YELLOW);

    }
    
}
