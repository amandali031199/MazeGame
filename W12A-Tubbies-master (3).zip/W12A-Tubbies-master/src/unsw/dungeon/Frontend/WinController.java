package unsw.dungeon.Frontend;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import unsw.dungeon.DungeonApplication;

public class WinController {
     Stage stage;
     
	 public WinController(Stage primaryStage) {
		stage = primaryStage;
	}

	@FXML
	private Button level;
	
	@FXML
	private Button replay;
	
	@FXML
	private Text congrats;
	
	@FXML
	private Text text;
	
    @FXML
    void levelOnAction(ActionEvent event) throws IOException{
    	DungeonApplication a = new DungeonApplication();
    	a.LevelScene(stage);
    }
    
    @FXML
    void replayOnAction(ActionEvent event) throws IOException{
    	DungeonApplication a = new DungeonApplication();
    	int level = Integer.parseInt(stage.getTitle());
    	a.restart(stage,level);
    }
    
    @FXML
    public void initialize() {
    	congrats.setFill(Color.YELLOW);   	
    	text.setFill(Color.WHITE);
    }
    
}
