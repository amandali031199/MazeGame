package unsw.dungeon.Frontend;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import unsw.dungeon.*;
import unsw.dungeon.Observer.PickupObserver;

/**
 * A JavaFX controller for the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public class DungeonController{

    @FXML
    private GridPane squares;

    @FXML
    private Text key;
    
    @FXML
    private Text sword;
    
    @FXML
    private Text treasure;
    
    @FXML
    private Text potion;
    
    @FXML
    private Text lives;
    
    @FXML
    private Text goal;
    
    private List<ImageView> initialEntities;
    
    private Player player;
    
    @FXML
	private Button restart;
    
    @FXML
	private Button exit;
    
    private Dungeon dungeon;
    private HashMap<Entity, Node> hashes;
    private ArrayList<Ground> grounds;

    Stage stage;
    
    public DungeonController(Dungeon dungeon, List<ImageView> initialEntities, HashMap<Entity, Node> hashes,Stage primaryStage) {
        this.dungeon = dungeon;
        this.player = dungeon.getPlayer();
        this.initialEntities = new ArrayList<>(initialEntities);
        this.hashes = hashes;
        this.grounds = new ArrayList<>();
        stage = primaryStage;
    }

    @FXML
    public void initialize() {
        Image ground = new Image("/dirt2.jpeg");
        int level = Integer.parseInt(stage.getTitle());
        if (level == 1) goal.setText("GOAL:\nReach the Exit");
        if (level == 2) {
        	goal.setText("GOAL:\nPush Boulders\nOn All Floor Switches");
        	goal.setLayoutX(10);
        }
        if (level == 3) {
        	goal.setText("GOAL:\nCollect All Treasure");
        	goal.setLayoutX(15);
        }
        if (level == 4) {
        	goal.setText("GOAL:\nDestroy All Enemies");
        	goal.setLayoutX(10);
        }
        if (level == 5) {
        	goal.setText("GOAL:\nPush Boulders\nOn All Floor Switches\nOR\nReach the Exit");
        	goal.setLayoutX(10);
        }
        if (level == 6) {
        	goal.setText("GOAL:\nDestroy All Enemies\nAND\nCollect All Treasure");
        	goal.setLayoutX(10);
        }
        if (level == 7) {
        	goal.setText("GOAL:\nDestroy All Enemies\nOR\n(Push Boulders\nOn All Floor Switches\nAND\nCollect All Treasure");
        	goal.setLayoutX(10);
        }
        if (level == 8) {
        	goal.setText("GOAL:\nDestroy All Enemies\nAND\nPush Boulders\nOn All Floor Switches\nAND\nCollect All Treasure\nAND\nReach the Exit");
        	goal.setLayoutX(10);
        }
        
        // Add the ground first so it is below all other entities
        //if we want player to on top of portals etc switch order 
        for (int x = 0; x < dungeon.getWidth(); x++) {
            for (int y = 0; y < dungeon.getHeight(); y++) {
            	ImageView imageGround = new ImageView(ground);
            	imageGround.setFitHeight(32);
            	imageGround.setFitWidth(32);
                squares.add(imageGround, x, y);
                Ground g = new Ground(x, y, imageGround, dungeon);
                grounds.add(g);
                
            }
        }

        for (ImageView entity : initialEntities)
            squares.getChildren().add(entity);
    }

    public void update(Inventory invent) {
    	String sumKeys = Integer.toString(invent.sumKeys());
    	key.setText(sumKeys);
    	String sumSwords= Integer.toString(invent.sumSwords());
    	sword.setText(sumSwords);
    	String treasureCollected = Integer.toString(invent.TreasuresCollected());
    	treasure.setText(treasureCollected);
    	String numLives = Integer.toString(invent.numLives());
    	lives.setText(numLives);
    }
    
    public void updatePotion(int num) {
    	String time = Integer.toString(num);
    	potion.setText(time);
    }
	
	@FXML
    void exitOnAction(ActionEvent event) throws IOException {
    	DungeonApplication a = new DungeonApplication();
    	a.start(stage);	
    }
	
	@FXML
    void restartOnAction(ActionEvent event) throws IOException {
    	DungeonApplication a = new DungeonApplication();
    	int level = Integer.parseInt(stage.getTitle());
    	a.restart(stage,level);
    	
    }
	
    @FXML
    public void handleKeyPress(KeyEvent event) {
        switch (event.getCode()) {
        case UP:
            player.moveUp();
            break;
        case DOWN:
            player.moveDown();
            break;
        case LEFT:
            player.moveLeft();
            break;
        case RIGHT:
            player.moveRight();
            break;
        case SPACE:
        	player.getX();
        	player.getY();
        	player.pickUp();
        	removeEntity(player.getX(),player.getY());
        	break;
        default:
            break;
        }
    }
    
    public void removeEntity(int x, int y) {
		for (Entity i : hashes.keySet()) {
			if (i.getX() == x && i.getY() == y && i.collectable()) {
				hashes.get(i).setVisible(false);
			}
    	}
	}
    
    public void switchDoor(int x, int y, Door door) {
		for (Entity i : hashes.keySet()) {
			if (i.getX() == x && i.getY() == y && i instanceof Door) {
				ImageView view = (ImageView) hashes.get(i);
	    		Image v = new Image("/open_door.png");
				view.setImage(v);
				//hashes.get(i).setVisible(false);
			}
		}
    }
    
    public void changeSlime(int x, int y) {
    	for (Ground g: grounds){
    		if (g.getX() == x  && g.getY() == y) {
    			g.setImage();
    		}
    	}
    }
    
    public void addEntity(int x, int y) {
		for (Entity i : hashes.keySet()) {
			if (i.getX() == x && i.getY() == y && i instanceof Key) {
				hashes.get(i).setVisible(true);
			}
		}
    }
    
    public void removeEnemy(int x, int y) {
		for (Entity i : hashes.keySet()) {
			if (i.getX() == x && i.getY() == y && (i instanceof Enemy)) {
				hashes.get(i).setVisible(false);
			}
    	}
	}
    
    public void addGlow() {
    	for (Entity i: hashes.keySet()) {
    		if (i instanceof Player) {
    			ImageView view = (ImageView) hashes.get(i);
	    		Image v = new Image("/glow.png");
	    		view.setFitHeight(32);
	    		view.setFitWidth(32);
				view.setImage(v);
    		}
    	}
    }
    
    public void removeGlow() {
    	for (Entity i: hashes.keySet()) {
    		if (i instanceof Player) {
    			ImageView view = (ImageView) hashes.get(i);
	    		Image v = new Image("/human_new.png");
	    		view.setFitHeight(32);
	    		view.setFitWidth(32);
				view.setImage(v);
    		}
    	}
    }

	public void win() throws IOException {
		// TODO Auto-generated method stub
		DungeonApplication a = new DungeonApplication();
		a.WinScene(stage);
	}
	
	public void lost() throws IOException {
		// TODO Auto-generated method stub
		DungeonApplication a = new DungeonApplication();
		a.FailScene(stage);
	}
	
}


