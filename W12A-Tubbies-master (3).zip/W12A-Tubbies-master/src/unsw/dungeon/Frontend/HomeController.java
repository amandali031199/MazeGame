package unsw.dungeon.Frontend;

import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import unsw.dungeon.DungeonApplication;

public class HomeController {
     Stage stage;
     
	 public HomeController(Stage primaryStage) {
		stage = primaryStage;
	}
	
	@FXML
    private Pane pane;

	
	@FXML
	private ImageView level;
	
	@FXML
	private ImageView dungeon;
	
    @FXML
    public void levelOnAction() throws IOException {
    	DungeonApplication a = new DungeonApplication();
    	a.LevelScene(stage);
    }
    
    @FXML
    public void initialize() {

    }
    
}
