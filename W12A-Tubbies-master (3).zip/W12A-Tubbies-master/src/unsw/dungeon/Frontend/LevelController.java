package unsw.dungeon.Frontend;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import unsw.dungeon.DungeonApplication;

public class LevelController {
     Stage stage;
     
	 public LevelController(Stage primaryStage) {
		stage = primaryStage;
	}
	
	@FXML
    private Pane pane;

	@FXML
	private Button level1;
	
	@FXML
	private Button level2;
	
	@FXML
	private Button level3;
	
	@FXML
	private Button level4;
	
	@FXML
	private Button level5;
	
	@FXML
	private Button level6;
	
	@FXML
	private Button level7;
	
	@FXML
	private Button level8;
	
	
	@FXML
	private Text title;
	
    @FXML
    void level1OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,1);
    
    }
    
    @FXML
    void level2OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,2);
    
    }
    
    @FXML
    void level3OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,3); 
    }
    
    @FXML
    void level4OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,4);  
    }
    
    @FXML
    void level5OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,5); 
    }
    
    @FXML
    void level6OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,6);  
    }
    
    @FXML
    void level7OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,7); 
    }
    
    @FXML
    void level8OnAction(ActionEvent event) throws IOException {
    	System.out.println("choose level");
    	DungeonApplication a = new DungeonApplication();
    	a.InstructionScene(stage,8);  
    }
    @FXML
    public void initialize() {

    }
    
}
