package unsw.dungeon;

import java.util.ArrayList;

import unsw.dungeon.Observer.EnemyObservable;
import unsw.dungeon.Observer.EnemyObserver;
import unsw.dungeon.Observer.PickupObserver;
import unsw.dungeon.State.Collected;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.NotCollected;

public class Potion extends Entity implements PickupObserver,EnemyObservable{
    
	EntityState collected;
    EntityState notcollected;    
    EntityState entityState;
    private Dungeon dungeon;
    private ArrayList<EnemyObserver> enemyObservers;

 
    public Potion(Dungeon dungeon,int x, int y){
    	super(x,y);
    	this.dungeon = dungeon;
        this.enemyObservers = new ArrayList<>();
    	collected = new Collected (this);
    	notcollected = new NotCollected (this);
    	entityState = notcollected;
    }
    
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }

    public EntityState GetState() {
    	return this.entityState;
    }
    public EntityState GetCollectedState() { return collected; }
    public EntityState GetNotCollectedState() { return notcollected; }
    public void appear() {
    	entityState.change(dungeon);
    	setEntityState(notcollected);
    }
    
    public void disappear() {
    	entityState.change(dungeon);
    	//change entitystate
    	setEntityState(collected);
    	//add to inventory
    	notifyObservers();
    	// tell enemy
    	notifyObserver(true);
    }
    
    @Override
	public void register(EnemyObserver o) {
		 enemyObservers.add(o);
	}

	@Override
	public void unregister(EnemyObserver o) {
		int observerIndex = enemyObservers.indexOf(o);
		enemyObservers.remove(observerIndex);

	}

	@Override
	public void notifyObserver(boolean b) {
		for(EnemyObserver o: enemyObservers){
			o.changemoving(b);
		}
	}
	
	@Override
	public void update() {
		this.disappear();
	}
	
	@Override	
	public boolean collectable() {
		return true;
	}

	@Override
	public void notifyObserver(int x, int y) {		
	}
}
