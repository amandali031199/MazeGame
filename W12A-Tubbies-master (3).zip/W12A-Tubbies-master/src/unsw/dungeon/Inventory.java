package unsw.dungeon;

import java.util.ArrayList;
import java.util.concurrent.Executors;
import javafx.util.Duration;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

import java.util.concurrent.ExecutorService;

import unsw.dungeon.TimeLimit;
import unsw.dungeon.Observer.GoalObservable;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.Observer.InventObserver;

import java.io.IOException;

public class Inventory implements InventObserver,GoalObservable {
    private ArrayList<Entity> entities;
	ExecutorService cachedThreadPool;
	private Dungeon dungeon;
    private ArrayList<GoalObserver> goalObservers;
    private int lives;
    private int countdown;
    private Timeline timeline;

    public Inventory(Dungeon dungeon) {
    	this.entities = new ArrayList<Entity>();
        this.dungeon = dungeon;
        this.goalObservers = new ArrayList<>();
    	cachedThreadPool = Executors.newCachedThreadPool();
    	dungeon.setGoalObservers(this);
    	lives = 0;
        this.countdown = 0;
    

    }
 
    public boolean isEmpty() {
    	return entities.isEmpty();
    }
    
    public boolean containsEntity(Entity e) {
    	return entities.contains(e);
    }
    public void addEntity(Entity e){
    	entities.add(e);
    	int t = TreasuresCollected();
    	notifyGoals(t,e,dungeon);
    	dungeon.updateInvent(this);
    }
    
    /**
     * calculate treasure collected
     * @return
     */
    public int TreasuresCollected() {
    	int i = 0;
    	for (Entity e : entities) {
    		if (e instanceof Treasure)i++;
    	}
    	return i;
    }
    
    /**
     * set timer for potion when potion collected
     * @param entity
     * @param period
     */
    public void addPotion(Entity e, long period){

    	entities.add(e);
    	TimeLimit timeLimit = new TimeLimit(this, e, period, dungeon);
    	// register enemies
    	dungeon.registerEnemies(timeLimit);
    	countdown = countdown + 5;
    	int start = countdown;
        if (timeline != null) {timeline.stop();}
        dungeon.setCountdown(countdown);
        countdown--;
		timeline = new Timeline( new KeyFrame(Duration.millis(1000), ev -> {
	        dungeon.setCountdown(countdown);
	        countdown--;
	    }));
		timeline.setCycleCount(start);
		timeline.play();
		dungeon.addGlow();
		cachedThreadPool.execute(timeLimit); 
		if (countdown == 0) {
			dungeon.removeGlow();
		}
    }
    
    /**
     * remove potion from inventory when time is up (5 sec after it was added)
     *  or when timer hits 0 remove all potions
     * @param e
     */
    public void removeEntity(Entity e) {
    	entities.remove(e);
		dungeon.updateInvent(this);
    }

	@Override
	public void update(Entity e) {
		// TODO Auto-generated method stub
		if (entities.contains(e) && !(e instanceof Treasure)) removeEntity(e);
		else {
			if (e instanceof Potion) addPotion(e, 5000);
			else addEntity(e);
		}
		//if in, delete
	}
	
	/**
	 * find key
	 * @return key
	 */
	public Key numKeys() {
		Key found = null;
		for (Entity e:entities) {
			if (e instanceof Key) {
				found = (Key)e;
			}
		}
		return found;
	}
	
	public int sumKeys() {
		int sum = 0;
		for (Entity e:entities) {
			if (e instanceof Key) {
				sum++;
			}
		}
		return sum;
	}
	
	public int numLives() {
		int num = this.lives;
		for (Entity e:entities) {
			if (e instanceof Lives) {
				num++;
			}
		}
		return num;
	}
	
	public void removeLife() {
		for (Entity e:entities) {
			if (e instanceof Lives) {
				this.removeEntity(e);
				break;
			}
		}
		dungeon.updateInvent(this);
	}
	/**
	 * find potion
	 * @return potion
	 */
	public Potion numPotions() {
		Potion found = null;
		for (Entity e:entities) {
			if (e instanceof Potion) {
				found = (Potion) e;
			}
		}
		return found;
	}


	public void useSword() {
		Sword s = numSwords();
		s.checkUse();
		dungeon.updateInvent(this);
	}
	public Key numKeys(int id) {
		Key found = null;
		for (Entity e:entities) {
			if (e instanceof Key) {
				found = checkCorresponding((Key) e, id);
			}
		}
		return found;
	}
	
	/**
	 * check if key is right id
	 * @param k
	 * @param id
	 * @return key
	 */
	private Key checkCorresponding(Key k, int id) {
		if (k.rightId(id)) {
			return k;
		} 
		return null;
	}
	
	/**
	 * find sword
	 * @return sword found or null
	 */
	public Sword numSwords() {
		Sword found = null;
		for (Entity e:entities) {
			if (e instanceof Sword) {
				found = (Sword)e;
			}
		}
		return found;
	}
	
	public int sumSwords() {
		int hits = 0;
		for (Entity e:entities) {
			if (e instanceof Sword) {
				Sword s = (Sword) e;
				hits = s.getHits();
			}
		}
		return hits;
	}

	/**
	 * 	find, remove current key/sword from inventory
	 *  put back into dungeon, make it appear 
	 */
	public void switchKey() {
		Key k = numKeys();
		if (k != null) {
			removeEntity(k);
			dungeon.addEntity(k.getX(), k.getY());
			//add back to dungeon
			k.appear();
		}
	}

	@Override
	public void register(GoalObserver o) {
		goalObservers.add(o);
	}

	@Override
	public void unregister(GoalObserver o) {
		int observerIndex = goalObservers.indexOf(o);
		goalObservers.remove(observerIndex);
	}

	@Override
	public void notifyGoals(int i,Entity e,Dungeon d) {
		// TODO Auto-generated method stub
		for(GoalObserver o: goalObservers){
			try {
				o.update(i,e,dungeon);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}



    
}