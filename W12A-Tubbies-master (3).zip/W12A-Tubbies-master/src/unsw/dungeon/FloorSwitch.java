package unsw.dungeon;

import unsw.dungeon.Observer.SwitchObserver;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.HasBoulder;
import unsw.dungeon.State.NoBoulder;

public class FloorSwitch extends Entity implements SwitchObserver{
    
	EntityState noboulder;
    EntityState hasboulder;    
    EntityState entityState;
    private Dungeon dungeon;
 
    public FloorSwitch(Dungeon dungeon,int x, int y){
    	super(x,y);
    	this.dungeon = dungeon;
    	hasboulder = new HasBoulder (this);
    	noboulder= new NoBoulder (this);
    	entityState = noboulder;
    }
    
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }

    public EntityState getEntityState() {
    	return entityState;
    }
    
    public void trigger() {
    	entityState.trigger(dungeon);
    }
    public void untrigger() {
    	entityState.untrigger(dungeon);
    }
    public void disappear() {
    	entityState.untrigger(dungeon);
    }
    
    public EntityState GetTriggerState() { return hasboulder; }
    public EntityState GetUntriggerState() { return noboulder; }

	@Override
	public void update(int newx,int newy, int oldx, int oldy) {
		if (newx == getX() && newy == getY()) {
			setEntityState(hasboulder);
			trigger();
		}
		else {	
			if (this.getEntityState() == this.GetTriggerState() && oldx == getX() && oldy == getY()) {
				setEntityState(noboulder);
				untrigger();
			}
		}	
	}
	
	

}
