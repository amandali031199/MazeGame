package unsw.dungeon;

import unsw.dungeon.State.Collected;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.NotCollected;

public class Sword extends Entity{
    
	EntityState collected;
    EntityState notcollected;    
    EntityState entityState;
    private int hits;
    private Dungeon dungeon;

 
    public Sword(Dungeon dungeon,int x, int y){
    	super(x,y);
    	this.dungeon = dungeon;
    	collected = new Collected (this);
    	notcollected = new NotCollected (this);
    	entityState = notcollected;
    	this.hits = 5;
    }
    
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }

    public EntityState GetState() {
    	return this.entityState;
    }
    
    public void appear() {
    	entityState.change(dungeon);
    	setEntityState(notcollected);
    }
    
    public void disappear() {
    	
    	entityState.change(dungeon);
    	//change entitystate
    	setEntityState(collected);
    	//add to inventory
    	notifyObservers();
    }
    
    public EntityState GetCollectedState() { return collected; }
    public EntityState GetNotCollectedState() { return notcollected; }
    
    @Override
    public boolean collectable() {
    	return true;
    }
    /** 
     * check if sword is used
     * decrease hits left for swords once used
     */
    public void checkUse() {
    	if (hits == 1) {
    		notifyObservers();
    	} else {
    		setHits(hits - 1);
    	}
    }
    
    public int getHits() {
    	return hits;
    }
    
    /**
     * set hits left for sword
     * @param h
     */
    public void setHits(int h) {
    	hits = h;
    }
	@Override
	public void update() {
		// TODO Auto-generated method stub
		this.disappear();
	}
}
