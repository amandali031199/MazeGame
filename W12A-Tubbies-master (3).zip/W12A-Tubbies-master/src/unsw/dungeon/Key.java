package unsw.dungeon;

import unsw.dungeon.Observer.PickupObserver;
import unsw.dungeon.State.Collected;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.NotCollected;

public class Key extends Entity implements PickupObserver{
    
	EntityState collected;
    EntityState notcollected;    
    EntityState entityState;
    private Dungeon dungeon;
    private int id;

 
    public Key(Dungeon dungeon,int x, int y, int id){
    	super(x,y);
    	this.dungeon = dungeon;
    	this.id = id;
    	collected = new Collected (this);
    	notcollected = new NotCollected (this);
    	entityState = notcollected;
    }
    
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }

    public EntityState GetState() {
    	return this.entityState;
    }
    
    public void appear() {
    	entityState.change(dungeon);
    	setEntityState(notcollected);
    }
    
    public void disappear() {
    	entityState.change(dungeon);
    	//change entitystate
    	setEntityState(collected);
    	//add to inventory
    	notifyObservers();
    }
    
    public EntityState GetCollectedState() { return collected; }
    public EntityState GetNotCollectedState() { return notcollected; }

//    public EntityState GetState() {
//    	return this.entityState;
//    }
    @Override
    public boolean collectable() {
    	return true;
    }

	@Override
	public void update() {
		// TODO Auto-generated method stub
		//can be picked up : do action 
		this.disappear();
		//make key disappear (change state), add key to inventory
		
	}
	
	public boolean rightId(int id) {
		if (this.id == id) {
			return true;
		}
		return false;
	}
	
   public int getId() {
    	return this.id;
    }

}
