package unsw.dungeon;

import java.awt.Button;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import unsw.dungeon.Frontend.DungeonController;
import unsw.dungeon.Frontend.DungeonControllerLoader;
import unsw.dungeon.Frontend.HomeController;
import unsw.dungeon.Frontend.LevelController;
import unsw.dungeon.Frontend.PlayController;
import unsw.dungeon.Frontend.WinController;

public class DungeonApplication extends Application {
	
	@Override
    public void start(Stage primaryStage) throws IOException {
		//InstructionScene(primaryStage,5);
//		DungeonApplication a = new DungeonApplication();
//    	a.DungeonScene(primaryStage,5);
    	HomeController controller = new HomeController(primaryStage);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("Home.fxml"));
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        root.requestFocus();
        primaryStage.setScene(scene);
     
        primaryStage.show();

    }
	
	// restart the same level
	public void restart(Stage primaryStage,int levelnum) throws IOException {
	    DungeonScene(primaryStage,levelnum);
	}
	 
	public void LevelScene(Stage primaryStage) throws IOException {
    	LevelController controller = new LevelController(primaryStage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Level.fxml"));
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();

	}
	
	 public void InstructionScene(Stage primaryStage,int num) throws IOException {
	    	PlayController controller = new PlayController(primaryStage,num);
	    	String file = "Level" + num + "instructions.fxml";
	    	//String file = "maze.json";
	        FXMLLoader loader = new FXMLLoader(getClass().getResource(file));
	        loader.setController(controller);
	        
	        Parent root = loader.load();
	        Scene scene = new Scene(root);
	        root.requestFocus();
	        primaryStage.setScene(scene);
	        primaryStage.show();

	 }
	 
    // win level pop up
    public void WinScene(Stage stage) throws IOException{
    	WinController controller = new WinController(stage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("WinLevel.fxml"));
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
       
    }
    
    
    // fail level pop up
    public void FailScene(Stage stage) throws IOException{
    	WinController controller = new WinController(stage);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FailedLevel.fxml"));
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
       
    }
    
    // show dungeon scene 
    public void DungeonScene(Stage stage,int num) throws IOException {
    	stage.setTitle(Integer.toString(num));
    	String file = "level" + num + ".json";
        DungeonControllerLoader dungeonLoader = new DungeonControllerLoader(file);
        DungeonController controller = dungeonLoader.loadController(num,stage);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("DungeonView.fxml"));
        loader.setController(controller);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        root.requestFocus();
        stage.setScene(scene);
        stage.show();
    } 
    
    public static void main(String[] args) {
        launch(args);
    }

}
