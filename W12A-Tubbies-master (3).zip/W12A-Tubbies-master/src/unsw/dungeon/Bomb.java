package unsw.dungeon;

import unsw.dungeon.Observer.PickupObserver;
import unsw.dungeon.State.Collected;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.NotCollected;

public class Bomb extends Entity implements PickupObserver{
    
	EntityState collected;
    EntityState notcollected;    
    EntityState entityState;
    private Dungeon dungeon;

 
    public Bomb(Dungeon dungeon,int x, int y){
    	super(x,y);
    	this.dungeon = dungeon;
    	collected = new Collected (this);
    	notcollected = new NotCollected (this);
    	entityState = notcollected;
    }
    
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }
    
    public void appear() {
    	entityState.change(dungeon);
    }
    
    public void disappear() {
    	entityState.change(dungeon);
    }
    
    public EntityState GetCollectedState() { return collected; }
    public EntityState GetNotCollectedState() { return notcollected; }

    @Override
    public boolean collectable() {
    	return true;
    }

	@Override
	public void update() {
		
	}
}
