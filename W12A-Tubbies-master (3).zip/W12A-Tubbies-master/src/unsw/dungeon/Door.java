package unsw.dungeon;

import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.Locked;
import unsw.dungeon.State.Unlocked;

public class Door extends Entity {
	private int id;
	EntityState unlocked;
    EntityState locked;    
    EntityState entityState;
	private Dungeon dungeon;
	
    public Door(Dungeon dungeon, int x, int y, int id) {
        super(x, y);
        this.id = id;
        this.dungeon = dungeon;
    	unlocked = new Unlocked (this);
    	locked = new Locked (this);
    	entityState = locked;
    }
    
    /**
     * change door state
     * @param newEntityState
     */
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }
    
    public void unlock() {
    	
    	entityState.change(dungeon);
    	//change entitystate
    	dungeon.switchDoor(this.getX(), this.getY(), this);
    
    	setEntityState(unlocked);
    	
    }
    
    /**
     * check if door is locked
     * @return
     */
    public boolean isLocked() {
    	if (entityState instanceof Locked) {
    		return true;
    	} 
    	return false;
    }
    
    @Override 
    public boolean checkPosition(Player p){
    	//check four adjacent blocks
		if (this.getX() == p.getX() - 1 && this.getY() == p.getY()) {
			return true;
		} else if (this.getX() == p.getX() + 1 && this.getY() == p.getY()) {
			return true;
		} else if (this.getX() == p.getX() && this.getY() == p.getY() - 1) {
			return true;
		} else if (this.getX() == p.getX() && this.getY() == p.getY() + 1) {
			return true;
		}
		return false;
    }
    public EntityState GetLockedState() { return locked; }
    public EntityState GetUnlockedState() { return unlocked; }


    public EntityState GetState() {
    	return this.entityState;
    }
    public int getId() {
    	return this.id;
    }
    
}
