package unsw.dungeon;

import java.io.IOException;
import java.util.ArrayList;

import javafx.beans.property.IntegerProperty;
import unsw.dungeon.Observer.EnemyObservable;
import unsw.dungeon.Observer.EnemyObserver;
import unsw.dungeon.Observer.GoalObservable;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.Strategy.Move;
import unsw.dungeon.Strategy.MoveAway;
import unsw.dungeon.Strategy.MoveNormally;

public class Enemy extends Entity implements EnemyObserver,GoalObservable {
    private Dungeon dungeon;

	public Move MovingType;
	private EnemyObservable Player;
    private ArrayList<GoalObserver> goalObservers;

	public Enemy(Dungeon dungeon, int x, int y,Player p) {
	        super(x, y);
	        this.dungeon = dungeon;
			this.setMovingAbility(new MoveNormally());
	        this.goalObservers = new ArrayList<>();
	        Player = p;
	        p.register(this);
	}
	 
	public void registerObserver(Player p) {
		p.register(this);
	}

	@Override
	public void update(int px,int py, Player p) {
		this.Move(getX(),getY(),dungeon,x(),y(),px,py);
		//after moving check if now they are the same 
		if (this.checkPosition(p)) {
			p.notifyKill(this);
			//if sword is in inventory, remove enemy
			//else remove player, end game, mark goal as failed
		}	
	}

	public void killed() {
		//get rid of photo
		dungeon.removeEntity(this);
		notifyGoals(1,this,dungeon);
	}


	@Override

	public void changemoving(boolean haspotion) {
		// TODO Auto-generated method stub
		if (haspotion) {
			setMovingAbility(new MoveAway());
		} else {
			setMovingAbility(new MoveNormally());
		}
		
	}

	@Override
	public void register(GoalObserver o) {
		goalObservers.add(o);
	}

	@Override
	public void unregister(GoalObserver o) {
		int observerIndex = goalObservers.indexOf(o);
		goalObservers.remove(observerIndex);
	}


	@Override
	public void notifyGoals(int i,Entity e, Dungeon d) {
		// TODO Auto-generated method stub
		for(GoalObserver o: goalObservers){
			try {
				o.update(i,e,dungeon);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	
}
