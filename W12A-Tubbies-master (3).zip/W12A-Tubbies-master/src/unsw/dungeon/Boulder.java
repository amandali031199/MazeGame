package unsw.dungeon;

import java.util.ArrayList;

import unsw.dungeon.Observer.SwitchObservable;
import unsw.dungeon.Observer.SwitchObserver;

public class Boulder  extends Entity implements SwitchObservable{
	private Dungeon dungeon;
    private ArrayList<SwitchObserver> switchObservers;

    public Boulder(Dungeon dungeon, int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
        this.switchObservers = new ArrayList<>();
    }
    
    /**
     * move to new position by player
     * @param next position x
     * @param next position y
     * @return
     */
    public boolean moveByPlayer (int newx,int newy) {
    	if (dungeon.CanMove(newx,newy)) {
    		int oldx = getX();
    		int oldy = getY();
    		x().set(newx);
        	y().set(newy);
        	notifySwitches(newx,newy, oldx, oldy);
        	return true;
    	}
    	return false;
    	
    }
    
	@Override
	public void register(SwitchObserver o) {
		// TODO Auto-generated method stub
		 switchObservers.add(o);

	}

	@Override
	public void unregister(SwitchObserver o) {
		// TODO Auto-generated method stub
		int observerIndex = switchObservers.indexOf(o);
		switchObservers.remove(observerIndex);
		
	}

	@Override
	public void notifySwitches(int x,int y, int oldx, int oldy) {
		// TODO Auto-generated method stub
		for(SwitchObserver o: switchObservers){
			o.update(x,y, oldx, oldy);
		}
	}
}
