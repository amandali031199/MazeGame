package unsw.dungeon;

import unsw.dungeon.Goals.GoalInterface;

public class Level {
	private Dungeon dungeon;
	private GoalInterface goal;
	private boolean isComplex;
	
	public Level(Dungeon dungeon, GoalInterface goal,Boolean iscomplex) {
		this.dungeon = dungeon;
		this.goal = goal;
		this.isComplex = iscomplex;
	}
	
	public void registerTreasureGoal(Inventory i) {
		goal.hasTreasureGoal(i);
		
	}
	
	public boolean getIsComplex() {
		return isComplex;
	}
	
	public void registerSwitchGoal() {
		goal.hasSwitchGoal(dungeon);
	}
	
	public void registerEnemiesGoal(Enemy enemy) {
		 goal.hasEnemyGoal(enemy);
	
	}
	
	public void registerExitGoal(Player player) {
		goal.hasExitGoal(player);
		
	}
}