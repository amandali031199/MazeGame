package unsw.dungeon;

public class Exit extends Entity{
	private Dungeon dungeon;

    public Exit(Dungeon dungeon, int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
    }

}
