/**
 *
 */
package unsw.dungeon;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.layout.GridPane;
import unsw.dungeon.Frontend.DungeonController;
import unsw.dungeon.Observer.EnemyObserver;
import unsw.dungeon.Observer.GoalObservable;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.Observer.SwitchObserver;

/**
 * A dungeon in the interactive dungeon player.
 *
 * A dungeon can contain many entities, each occupy a square. More than one
 * entity can occupy the same square.
 *
 * @author Robert Clifton-Everest
 *
 */
public class Dungeon implements GoalObservable{

    private int width, height;
    private List<Entity> entities;
    private List<Entity> AllEntities;
    private int triggeredSwitches = 0;
    private Player player;
    private DungeonController controller;
    GridPane grid;
    private Level level;
    private ArrayList<GoalObserver> goalObservers;
    
    public Dungeon(int width, int height) {
        this.width = width;
        this.height = height;
        this.entities = new ArrayList<>();
        this.AllEntities = new ArrayList<>();
        this.player = null;
        this.goalObservers = new ArrayList<>();
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void setCountdown(int num) {
    	controller.updatePotion(num);
    }
    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }
    
    public void updateInvent(Inventory invent) {
    	controller.update(invent);
    }
    public void setLevel(Level level) {
    	this.level = level;
    }
    public void addEntity(Entity entity) {
        entities.add(entity);
    }
    
    public void addEntity(int x, int y) {
    	controller.addEntity(x,y);
    }
    
    public void removeEntity(Entity entity) {
    	entities.remove(entity);
    }
  
    
    public void switchDoor(int x, int y, Door door) {
    	controller.switchDoor(x,y, door);
    }

    /**
     * store all initial entities in the dungeon
     * @param entity
     */
    public void recordEntity(Entity entity) {
        AllEntities.add(entity);
    }
    
    /**
     * register all observers to corresponding subjects
     */
    public void initObservers() {
		findPlayer();
		
		for (Entity e: entities) {
			if (e.collectable()) {
				player.addObserver(e);
				e.addObserver(player.getInventory());
				if (e instanceof Potion) {
					registerEnemies(e);
				} 
			} else if (e instanceof Door) {
				player.addObserver(e);
			} else if (e instanceof Boulder) {
				registerSwitches(e);
			} else if (e instanceof Enemy) {
				level.registerEnemiesGoal((Enemy)e);
			} else if (e instanceof Exit) {
				level.registerExitGoal(player);
			} else if (e instanceof FloorSwitch) {
				level.registerSwitchGoal();
			} 
		}
	}
    
    public void notifyFire() {
    	ArrayList<Entity> fires = new ArrayList<Entity>();
    	for (Entity e: entities) {
    		if (e instanceof Fire) {
    			fires.add(e);
    		}
    	}
    	for (Entity f: fires) {
    		if (f.checkPosition(player)) {
    			player.notifyDeathByFire();
    		}
    	}
    }
    private void ifHasSlime(int x, int y) {
    	for (Entity e: entities) {
    		if (e instanceof Slime) {
    			controller.changeSlime(x,y);
    			break;
    		}
    	}
    }
    public void notifySlime(int x, int y) {
    	ifHasSlime(x,y);	
    	ArrayList<Entity> slimes = new ArrayList<Entity>();
    	for (Entity e: entities) {
    		if (e instanceof Slime) {
    			slimes.add(e);
    		}
    	}
    	for (Entity s: slimes) {
    		if (s.checkPosition(player)) {
    			player.notifyDeathBySlime();
    		}
    	}
    }
    
    public boolean containsSlime() {
    	boolean contains = false;
    	for (Entity e: this.entities) {
    		if (e instanceof Slime) {
    			contains = true;
    		}
    	}
    	return contains;
    }
    /**
     * get number of triggered switches
     * @return int
     */
    public int getTriggeredSwitches() {
		return triggeredSwitches;
	}
    
    
    /**
     * set number of triggered switches
     */
	public void setTriggeredSwitches(int num,Entity e) {
		if (triggeredSwitches > 0 && num < 0) {
			this.triggeredSwitches = triggeredSwitches + num;

		} else if (num > 0) {
			this.triggeredSwitches = triggeredSwitches + num;
		}
		notifyGoals(triggeredSwitches,e,this);
		
	}
	

	@Override
	public void notifyGoals(int i,Entity e,Dungeon d) {
		for(GoalObserver o: goalObservers){
			try {
				o.update(i,e,this);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	/** 
	 * register goal observers
	 * @param i
	 */
	public void setGoalObservers(Inventory i) {
    	level.registerTreasureGoal(i);
    }
    
	/** 
	 * check if entity can move to the sqaure
	 * @param x
	 * @param y
	 * @return boolean
	 */
	public boolean CanMove(int x, int y) {
		for (Entity e: entities) {
			// not go through walls and door
			if (e.getX() == x && e.getY() == y && e instanceof Wall) {
				return false;
			} else if (e.getX() == x && e.getY() == y && e instanceof Door) {
				return checkState((Door)e);
			}
		}
		return true;
	}
	
	public void addGlow() {
		controller.addGlow();
	}
	
	public void removeGlow() {
		controller.removeGlow();
	}
	
	/**
	 * check if enemy can move to the square
	 * includes not moving boulder
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean EnemyCanMove(int x, int y) {
		for (Entity e: entities) {
			// not go through walls and door
			if (!CanMove(x,y)) {
				return false;	
			} else if (e.getX() == x && e.getY() == y && e instanceof Boulder) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * check if player reaches exit
	 * @param x
	 * @param y
	 * @return boolean
	 */
	public boolean ReachExit(int x, int y) {
		for (Entity e: entities) {
			// not go through walls and door
			if (e.getX() == x && e.getY() == y && e instanceof Exit) {
				return true;
			} 
		}
		return false;
	}
	
	/** 
	 * check door state
	 * @param d
	 * @return boolean
	 */
	private boolean checkState(Door d) {
		if (d.isLocked()) {
			return false;
		}
		return true;
	}
	
	/**
	 * check if the position is a portal
	 * @param x
	 * @param y
	 * @return portal id
	 */
	public int isPortal(int x,int y) {
		for (Entity e: entities) {
			if (e.getX() == x && e.getY() == y && e instanceof Portal) {
				return ((Portal) e).getId();
			}
		}
		return -1;
	}
	
	/**
	 * check if position is a boulder
	 * @param x
	 * @param y
	 * @return boulder entity
	 */

	public Entity isBoulder(int x,int y) {
		for (Entity e: entities) {
			if (e.getX() == x && e.getY() == y && e instanceof Boulder) {
				return e;
			}
		}
		return null;
	}
		
	public int noOfSwitches() {
		int i = 0;
		for (Entity e: AllEntities) {
			if (e instanceof FloorSwitch) i++;
		}
		return i;
	}
	
	public int noOfTreasures() {
		int i = 0;
		for (Entity e: AllEntities) {
			if (e instanceof Treasure)i++;
		}
		return i;
	}
	
	public int noOfEnemies() {
		int i = 0;
		for (Entity e: AllEntities) {
			if (e instanceof Enemy)i++;
		}
		return i;
	}
	
	/**
	 * find another corresponding portal w same id
	 * @param id
	 * @param x
	 * @param y
	 * @return portal
	 */
	public Entity getAnotherPortal(int id,int x,int y) {
		for (Entity e: entities) {
			if (e.getX() != x && e.getY() != y && e instanceof Portal 
				&& ((Portal) e).getId() == id) {
				return e;
			}
		}
		return null;
	}
	/**
	 * set player entity
	 */
	private void findPlayer() {
		for (Entity e:entities) {
			if (e instanceof Player) {
				setPlayer((Player)e);
			}
		}
	}
	
	/**
	 * register enemy observer
	 * @param entity
	 */
	public void registerEnemies(Entity b) {
		for (Entity e: entities) {
			if (e instanceof Enemy && b instanceof Potion) {
				((Potion)b).register((EnemyObserver)e);
			} 
		}
	}
	public void registerEnemies(TimeLimit t) {
		for (Entity e: entities) {
			if (e instanceof Enemy) {
				t.register((EnemyObserver)e);
			} 
		}
	}
	
	/**
	 * register switch observer
	 * @param entity
	 */
	public void registerSwitches(Entity b) {
		int i = 0;
		for (Entity e: entities) {
			if (e instanceof FloorSwitch) {
				((Boulder)b).register((SwitchObserver)e);
				i++;
			}
		}
	}
	
	public boolean containsEntity(Entity e) {
		return entities.contains(e);
	}

	@Override
	public void register(GoalObserver o) {
		goalObservers.add(o);
	}

	@Override
	public void unregister(GoalObserver o) {
		int observerIndex = goalObservers.indexOf(o);
		goalObservers.remove(observerIndex);
	}

	public void setController(DungeonController d) {
		// TODO Auto-generated method stub
		controller = d;
	}
	
	public DungeonController getController() {
		// TODO Auto-generated method stub
		return controller;
	}
	public void removeEnemy(int x,int y) {
		controller.removeEnemy(x, y);
	}

//	public void removePlayer(int x, int y) {
//		// TODO Auto-generated method stub
//		controller.removePlayer(x, y);
//	}
	
	public boolean isComplexLevel() {
		return level.getIsComplex();
	}
	
	public void win() {
		try {
			controller.win();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void lost() {
		try {
			controller.lost();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
