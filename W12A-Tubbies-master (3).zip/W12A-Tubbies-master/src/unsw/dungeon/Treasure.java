package unsw.dungeon;

import java.util.ArrayList;

import unsw.dungeon.State.Collected;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.NotCollected;

public class Treasure extends Entity{
    
	EntityState collected;
    EntityState notcollected;    
    EntityState entityState;
    private Dungeon dungeon;
 
    public Treasure(Dungeon dungeon,int x, int y){
    	super(x,y);
    	this.dungeon = dungeon;
    	collected = new Collected (this);
    	notcollected = new NotCollected (this);
    	entityState = notcollected;
    }
    
    void setEntityState(EntityState newEntityState){
    	entityState = newEntityState;
    }

    public EntityState GetState() {
    	return this.entityState;
    }
    
    public void appear() {
    	entityState.change(dungeon);
    	setEntityState(notcollected);
    }
    
    public void disappear() {
    	entityState.change(dungeon);
    	//change entitystate
    	setEntityState(collected);
    	//add to inventory
    	notifyObservers();
    }
    
    public EntityState GetCollectedState() { return collected; }
    public EntityState GetNotCollectedState() { return notcollected; }

	@Override
	public void update() {
		this.disappear();
	}
	
	@Override	
	public boolean collectable() {
		return true;
	}


	
}
