package unsw.dungeon;

import java.util.ArrayList;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import unsw.dungeon.Observer.InventObservable;
import unsw.dungeon.Observer.InventObserver;
import unsw.dungeon.Observer.PickupObserver;
import unsw.dungeon.Strategy.Move;

/**
 * An entity in the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public class Entity implements PickupObserver, InventObservable {

    // IntegerProperty is used so that changes to the entities position can be
    // externally observed.
    private IntegerProperty x, y;
    public Move MovingType;
    private ArrayList<InventObserver> invent = new ArrayList<InventObserver>();

    /**
     * Create an entity positioned in square (x,y)
     * @param x
     * @param y
     */
    public Entity(int x, int y) {
        this.x = new SimpleIntegerProperty(x);
        this.y = new SimpleIntegerProperty(y);
    }

    public IntegerProperty x() {
        return x;
    }

    public IntegerProperty y() {
        return y;
    }

    public int getY() {
        return y().get();
    }

    public int getX() {
        return x().get();
    }

    public void setX(Integer value) {
    	x().set(value);
    }
    
    public void setY(Integer value) {
    	y().set(value);
    }
	public void setMovingAbility(Move newMovingType){

        MovingType = newMovingType;
	}
	
	public void remove() {

	}
	
	public void Move(int x,int y,Dungeon dungeon,IntegerProperty x2,IntegerProperty y2,int px,int py) {
		MovingType.move(x,y,dungeon,x(),y(),px,py);
	}
	/**
	 * if the entity can be collected
	 * @return boolean
	 */
	public boolean collectable() {
		return false;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean checkPosition(Player p) {
		// TODO Auto-generated method stub
		if (this.getX() == p.getX() && this.getY() == p.getY()) {
			return true;
		}
		return false;
	}

	public void addObserver(InventObserver o) {
		invent.add(o);
		
	}
	
	@Override
	public void notifyObservers() {
		for (InventObserver i: invent) {
			i.update(this);
		}
	}
	  
}
