package unsw.dungeon.Observer;

import unsw.dungeon.Player;

public interface PickupObserver {
	public void update();
	public boolean checkPosition(Player p);
}
