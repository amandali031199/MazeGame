package unsw.dungeon.Observer;

import java.io.IOException;

import unsw.dungeon.Dungeon;

public interface GameObserver {
	public void update(Dungeon d) ;

}
