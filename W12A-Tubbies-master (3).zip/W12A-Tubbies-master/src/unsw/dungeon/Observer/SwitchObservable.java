package unsw.dungeon.Observer;

public interface SwitchObservable {
	public void register(SwitchObserver o);
	public void unregister(SwitchObserver o);
	public void notifySwitches(int x,int y, int oldx, int oldy);

}
