package unsw.dungeon.Observer;

public interface PickupObservable {
	public void addObserver(PickupObserver o);
	public void notifyPickUpObservers();
}