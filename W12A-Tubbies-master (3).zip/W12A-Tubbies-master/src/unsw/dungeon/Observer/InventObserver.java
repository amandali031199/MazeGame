package unsw.dungeon.Observer;

import unsw.dungeon.Entity;

public interface InventObserver {
	public void update(Entity e);
}