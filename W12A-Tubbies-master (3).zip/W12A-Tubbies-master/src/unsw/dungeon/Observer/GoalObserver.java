package unsw.dungeon.Observer;

import java.io.IOException;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

public interface GoalObserver {
	public void update(int i, Entity e,Dungeon d) throws IOException;

}
