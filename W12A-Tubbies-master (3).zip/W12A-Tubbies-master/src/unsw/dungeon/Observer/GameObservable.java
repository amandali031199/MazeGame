package unsw.dungeon.Observer;

import java.io.IOException;

import unsw.dungeon.Dungeon;

public interface GameObservable {
	public void register(GameObserver o);
	public void unregister(GameObserver o);
	public void notifyGame(Dungeon d);
}
