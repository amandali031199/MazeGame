package unsw.dungeon.Observer;

public interface SwitchObserver {

	void update(int x ,int y, int oldx, int oldy);

}
