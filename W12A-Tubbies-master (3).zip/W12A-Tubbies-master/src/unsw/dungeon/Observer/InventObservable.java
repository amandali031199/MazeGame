package unsw.dungeon.Observer;

public interface InventObservable {
	public void addObserver(InventObserver o);
	public void notifyObservers();
}