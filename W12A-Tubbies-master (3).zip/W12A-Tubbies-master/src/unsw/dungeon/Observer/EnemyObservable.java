package unsw.dungeon.Observer;

public interface EnemyObservable {
	public void register(EnemyObserver o);
	public void unregister(EnemyObserver o);
	public void notifyObserver(int x, int y);
	public void notifyObserver(boolean b);
}
