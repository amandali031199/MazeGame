package unsw.dungeon.Observer;

import unsw.dungeon.Player;

public interface EnemyObserver {
	public void update(int x,int y, Player p);
	public void changemoving(boolean haspotion);
}

