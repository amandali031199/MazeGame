package unsw.dungeon.Observer;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

public interface GoalObservable {
	public void register(GoalObserver o);
	public void unregister(GoalObserver o);
	void notifyGoals(int i,Entity e, Dungeon d);
}
