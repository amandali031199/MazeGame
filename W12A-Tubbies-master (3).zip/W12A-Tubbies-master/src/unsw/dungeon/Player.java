package unsw.dungeon;

import java.io.IOException;
import java.util.ArrayList;
import javafx.beans.property.IntegerProperty;
import unsw.dungeon.Observer.EnemyObservable;
import unsw.dungeon.Observer.EnemyObserver;
import unsw.dungeon.Observer.GoalObservable;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.Observer.PickupObservable;
import unsw.dungeon.Observer.PickupObserver;

/**
 * The player entity
 *
 */

public class Player extends Entity implements EnemyObservable, PickupObservable,GoalObservable {

    private static final int id = 0;
	private Dungeon dungeon;
    private ArrayList<EnemyObserver> enemyObservers;
    private ArrayList<PickupObserver> pickupObservers = new ArrayList<PickupObserver>();
    private ArrayList<GoalObserver> goalObservers;
    private Inventory inventory;
    
    /**
     * Create a player positioned in square (x,y)
     * @param x
     * @param y
     */
    public Player(Dungeon dungeon, int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
        this.goalObservers = new ArrayList<>();
        this.enemyObservers = new ArrayList<>();
        //make new inventory every time a new player is made
        this.inventory = new Inventory(this.dungeon);
    }
    
    /**
     * move up to upper square if permitted
     * notify observers when reach exit
     * notify enemy on player's movement
     */
    public void moveUp() {
    	int oldX = getX();
    	int oldY = getY();
        if ((getY() > 0) && dungeon.CanMove(getX(),getY()-1)) {
        	int PortalId = dungeon.isPortal(getX(),getY()-1);
        	if (!EnteredPortal(PortalId,x(),y(),getX(),getY()-1)) {
        		Entity b = dungeon.isBoulder(getX(),getY()-1);
        		Entity next = dungeon.isBoulder(getX(),getY()-2);
        		if (next == null && b != null && ((Boulder) b).moveByPlayer(getX(),getY()-2)){
        			y().set(getY() - 1);
        		} else if (b == null) {
            		y().set(getY() - 1);
        		}
        	}

        	if (dungeon.ReachExit(getX(), getY())) {
        		notifyGoals(1, this, dungeon);
        	} else {
        		notifyGoals(-1, this, dungeon);
        	}
        	notifyObserver(getX(),getY());
        	notifyDoor();
        	dungeon.notifyFire();
        	dungeon.notifySlime(oldX, oldY);

        }
    }
    
    /**
     * move down to lower square if permitted
     * notify observers when reach exit
     * notify enemy on player's movement
     */
    public void moveDown() {
    	int oldX = getX();
    	int oldY = getY();
        if (getY() < dungeon.getHeight() - 1
        	&& dungeon.CanMove(getX(),getY()+1)) {
        	int PortalId = dungeon.isPortal(getX(),getY()+1);
        	if (!EnteredPortal(PortalId,x(),y(),getX()+1,getY())) {
        		Entity b = dungeon.isBoulder(getX(),getY()+1);
        		Entity next = dungeon.isBoulder(getX(),getY()+2);
        		if (next == null && b != null && ((Boulder) b).moveByPlayer(getX(),getY()+2)){
        			y().set(getY() + 1);
        		} else if (b == null) {
            		y().set(getY() + 1);
        		}	
        	}
        	// reach exit
        	if (dungeon.ReachExit(getX(), getY())) {
        		notifyGoals(1, this, dungeon);
        	} else {
        		notifyGoals(-1, this, dungeon);
        	}
     		notifyObserver(getX(),getY());
     		notifyDoor();
     		dungeon.notifyFire();
        	dungeon.notifySlime(oldX, oldY);

        }         
    }
    
    /**
     * move left to left square if permitted
     * notify observers when reach exit
     * notify enemy on player's movement
     */
    public void moveLeft() {
    	int oldX = getX();
    	int oldY = getY();
        if (getX() > 0
        	 && dungeon.CanMove(getX()-1,getY())) {
        	int PortalId = dungeon.isPortal(getX()-1,getY());
    		if (!EnteredPortal(PortalId,x(),y(),getX()-1,getY())) {
    			Entity b = dungeon.isBoulder(getX()-1,getY());
        		Entity next = dungeon.isBoulder(getX()-2,getY());
    			if (next == null && b != null && ((Boulder) b).moveByPlayer(getX()-2,getY())){
    				x().set(getX() - 1);
        		} else if (b == null) {
        			x().set(getX() - 1);
        		}
    		}
    		// reach exit
        	if (dungeon.ReachExit(getX(), getY())) {
        		notifyGoals(1, this, dungeon);
        	} else {
        		notifyGoals(-1, this, dungeon);
        	}
    		// notify enemy
    		notifyObserver(getX(),getY());
    		notifyDoor();
    		dungeon.notifyFire();
        	dungeon.notifySlime(oldX, oldY);

        }

    }
    
    
    /**
     * move right to left square if permitted
     * notify observers when reach exit
     * notify enemy on player's movement
     */
    public void moveRight() {
    	int oldX = getX();
    	int oldY = getY();
        if (getX() < dungeon.getWidth() - 1
        	&& dungeon.CanMove(getX()+1,getY())) {
        	int PortalId = dungeon.isPortal(getX()+1,getY());
        	if (!EnteredPortal(PortalId,x(),y(),getX()+1,getY())) {
        		Entity b = dungeon.isBoulder(getX()+1,getY());
        		Entity next = dungeon.isBoulder(getX()+2,getY());
	        		if (next == null && b != null && ((Boulder) b).moveByPlayer(getX()+2,getY())){
	    				x().set(getX() + 1);
	        		} else if (b == null) {
	        			x().set(getX() + 1);
	        		}
        		
        	}
        	// reach exit
        	if (dungeon.ReachExit(getX(), getY())) {
        		notifyGoals(1, this, dungeon);
        	} else {
        		notifyGoals(-1, this, dungeon);
        	}
        	// notify enemy
        	notifyObserver(getX(),getY());
        	// notify d
        	notifyDoor();
        	dungeon.notifyFire();
        	dungeon.notifySlime(oldX, oldY);
        }

    }
    
    /**
     * check if player enter a portal
     * @param PortalId
     * @param x
     * @param y
     * @param x2
     * @param y2
     * @return
     */
    public boolean EnteredPortal(int PortalId,IntegerProperty x,IntegerProperty y,int x2,int y2) {
    	if (PortalId != -1) {
    		Entity e = dungeon.getAnotherPortal(PortalId, x2, y2);
    		x().set(e.getX());
    		y().set(e.getY());
    		return true;
    	}
    	return false;
    }
   
    
	@Override
	public void register(EnemyObserver o) {
		 enemyObservers.add(o);
	}

	@Override
	public void unregister(EnemyObserver o) {
		int observerIndex = enemyObservers.indexOf(o);
		enemyObservers.remove(observerIndex);

	}

	@Override
	public void notifyObserver(int x,int y) {
		// TODO Auto-generated method stub
		ArrayList<EnemyObserver> toRemove = new ArrayList<>();
		for(EnemyObserver o: enemyObservers){
			o.update(x,y, this);
		}
		//remove dead enemies from list of observers
		for (EnemyObserver o : enemyObservers) {
			Entity e = (Entity) o;
			if (!dungeon.containsEntity(e)) {
				toRemove.add(o);
			}
		}
		enemyObservers.removeAll(toRemove);
	}
	
	/** 
	 * pick up the entity 
	 * @return 
	 */
    public void pickUp() {
    	//check what ever is on square
    	notifyPickUpObservers();
    	notifyDoor();
    }
    

	@Override
	public void addObserver(PickupObserver o) {
		pickupObservers.add(o);
	}

	
	public void notifyPickUpObservers() {
	 	for(PickupObserver o: pickupObservers) { //all are collectables
	 		if(o.checkPosition(this)) {
	 			if (o instanceof Key) checkKeyInInventory(o);
	 			else if (o instanceof Sword) checkSwordInInventory(o);
	 			else o.update();
	 		}
	 	}
	}
	
	/**
	 * check if player is killed or enemy is killed when there are at same square
	 * @param enemy
	 */
	public void notifyKill(Enemy e) {
		if (inventory.numSwords() != null || inventory.numPotions() != null) { //have sword or potion
			e.killed();
			if (inventory.numSwords() != null) inventory.useSword();
			dungeon.removeEnemy(getX(), getY());
		} else {
			dungeon.removeEntity(this);
			dungeon.lost();
		}
	}
	
	public void notifyDeathByFire() {
		if (inventory.numLives() == 0) {
			dungeon.removeEntity(this);
			dungeon.lost();
		} else {
			inventory.removeLife();		
		}
	}
	
	public void notifyDeathBySlime() {
		dungeon.removeEntity(this);
		dungeon.lost();
	}
	
	/**
	 * check if door is open
	 */
	public void notifyDoor() {
	 	for(PickupObserver o: pickupObservers) { //all are collectables
	 		if(o.checkPosition(this) && o instanceof Door) {
	 			 checkOpen(o);
	 		} else update();
	 			//o.checkInInventory(inventory);
	 	}
	}
	
	public Inventory getInventory() {
		return this.inventory;
	}

	/**
	 * check if keys exist in inventory
	 * @param pickupobserver
	 * return key collected id
	 */
	public void checkKeyInInventory(PickupObserver o) {
		if (inventory.numKeys() != null) {
				dungeon.addEntity(inventory.numKeys());
				inventory.switchKey();
				o.update();
		} else {
			o.update();
		}
	}
	
	/**
	 * check if sword is in inventory
	 * @param o
	 */
	public void checkSwordInInventory(PickupObserver o) {
			if (inventory.numSwords() == null) {
				o.update();
			}
	}
	
	/**
	 * check for doors open
	 * @param pickupobserver
	 */
	public void checkOpen(PickupObserver o) {
			//already check position, door, need to check have key 
			Door d = (Door) o;
			Key k = inventory.numKeys(d.getId());
			if (k != null) { //right key right spot right door now unlock
				//d.update();
				d.unlock();
				inventory.removeEntity(k);
				//delete key from inventory
			}
	}

	@Override
	public void register(GoalObserver o) {
		goalObservers.add(o);
	}

	@Override
	public void unregister(GoalObserver o) {
		int observerIndex = goalObservers.indexOf(o);
		goalObservers.remove(observerIndex);
	}


	@Override
	public void notifyGoals(int i,Entity e, Dungeon d) {
		// TODO Auto-generated method stub
		for(GoalObserver o: goalObservers){
			try {
				o.update(i,e,dungeon);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	@Override
	public void notifyObserver(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
