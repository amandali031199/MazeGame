package unsw.dungeon;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Ground extends Entity {
	private ImageView image;
	private Dungeon dungeon;
	
    public Ground(int x, int y, ImageView image, Dungeon dungeon) {
        super(x, y);
        this.image = image;
        this.dungeon = dungeon;
    }

    public void setImage() {
		Image v = new Image("/slime.jpeg");
		image.setImage(v);
		image.setFitHeight(32);
        image.setFitWidth(32);
		Slime s = new Slime(getX(),getY());
		dungeon.addEntity(s);
    }
}