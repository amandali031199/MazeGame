package unsw.dungeon;

public class Fire extends Entity {
	private Dungeon dungeon;
	
    public Fire(Dungeon dungeon,int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
    }
    


}