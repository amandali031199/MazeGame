package unsw.dungeon.Goals;

import java.io.IOException;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Enemy;
import unsw.dungeon.Inventory;
import unsw.dungeon.Player;

public interface GoalInterface {
	public boolean checkCompleted(Dungeon dungeon);

	boolean hasEnemyGoal(Enemy e);
	boolean hasExitGoal(Player p);
	boolean hasSwitchGoal(Dungeon d);
	boolean hasTreasureGoal(Inventory i);

}