package unsw.dungeon.Goals;

import java.io.IOException;
import java.util.ArrayList;

import unsw.dungeon.*;
import unsw.dungeon.Observer.GameObservable;
import unsw.dungeon.Observer.GameObserver;
import unsw.dungeon.Observer.GoalObserver;


public class SwitchGoal implements GoalInterface,GoalObserver,GameObservable {

    private int triggeredSwitches = 0;
    private ArrayList<GameObserver> gameObservers = new ArrayList <>();

    /**
     * check if goal completed
     * @throws IOException 
     */
	@Override
	public boolean checkCompleted(Dungeon dungeon) {
		//check that all boulders in dungeon have the hasBoulder state
		if (triggeredSwitches == dungeon.noOfSwitches()) {
			System.out.println("switch goal done " );
			if (! dungeon.isComplexLevel())dungeon.win();
			
			return true;
		}
		System.out.println("switch goal not done");

		return false;
	}
	/**
	 * set number of triggered switches
	 * @param i
	 */
	public void setTriggeredSwitches(int i) {
		triggeredSwitches = i;
	}
	
	@Override
	public void update(int i,Entity e,Dungeon d) throws IOException {
		//if (e instanceof FloorSwitch) {
			setTriggeredSwitches(i);
			checkCompleted(d);
			notifyGame(d);

	}

	@Override
	public boolean hasEnemyGoal(Enemy e) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean hasExitGoal(Player p) {
		// TODO Auto-generated method stub
		return false;
	}
	/** 
	 * return true if have switch goal
	 */
	@Override
	public boolean hasSwitchGoal(Dungeon d) {
		d.register(this);
		return true;
	}
	@Override
	public boolean hasTreasureGoal(Inventory i) {
		// TODO Auto-generated method stub
		return false;
	}
	
	@Override
	public void register(GameObserver o) {
		// TODO Auto-generated method stub
		gameObservers.add(o);
	}

	@Override
	public void unregister(GameObserver o) {
		// TODO Auto-generated method stub
		int observerIndex = gameObservers.indexOf(o);
		gameObservers.remove(observerIndex);
	}

	@Override
	public void notifyGame(Dungeon d) {
		// TODO Auto-generated method stub
		for(GameObserver o: gameObservers){
			o.update(d);
		}
	}
	
	

}