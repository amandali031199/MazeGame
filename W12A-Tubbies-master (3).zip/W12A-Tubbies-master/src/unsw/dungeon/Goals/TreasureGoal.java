package unsw.dungeon.Goals;

import java.io.IOException;
import java.util.ArrayList;

import unsw.dungeon.*;
import unsw.dungeon.Observer.GameObservable;
import unsw.dungeon.Observer.GameObserver;
import unsw.dungeon.Observer.GoalObserver;

public class TreasureGoal implements GoalInterface,GoalObserver,GameObservable {
	
		private int treasures = 0;
	    private ArrayList<GameObserver> gameObservers = new ArrayList <>();
	    
	    /** 
	     * check if treasure goal completed
	     */
		@Override
		public boolean checkCompleted(Dungeon dungeon) {
			// TODO Auto-generated method stub
			//check that all boulders in dungeon have the hasBoulder state
			if (treasures == dungeon.noOfTreasures()) {
				System.out.println("treasure goal completed");
				if (! dungeon.isComplexLevel()) dungeon.win();
				return true;
			}
			System.out.println("treasure goal not completed");
			return false;
		}
		
		public void setTreasuresCollected(int e) {
			treasures = e;
		}

		@Override
		public void update(int i,Entity e,Dungeon d) {
			if (e instanceof Treasure) {
				setTreasuresCollected(i);
				checkCompleted(d);
				notifyGame(d);
			}
			
		}

		@Override
		public boolean hasEnemyGoal(Enemy e) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean hasExitGoal(Player p) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean hasSwitchGoal(Dungeon d) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean hasTreasureGoal(Inventory i) {
			// TODO Auto-generated method stub
			i.register(this);
			return true;
		}
		
		@Override
		public void register(GameObserver o) {
			// TODO Auto-generated method stub
			gameObservers.add(o);
		}

		@Override
		public void unregister(GameObserver o) {
			// TODO Auto-generated method stub
			int observerIndex = gameObservers.indexOf(o);
			gameObservers.remove(observerIndex);
		}

		@Override
		public void notifyGame(Dungeon d) {
			// TODO Auto-generated method stub
			for(GameObserver o: gameObservers){
				o.update(d);
			}
		}
		
		

}