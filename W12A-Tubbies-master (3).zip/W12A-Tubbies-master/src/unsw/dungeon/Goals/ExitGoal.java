package unsw.dungeon.Goals;

import java.io.IOException;
import java.util.ArrayList;

import unsw.dungeon.Observer.GameObservable;
import unsw.dungeon.Observer.GameObserver;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.*;

public class ExitGoal implements GoalInterface,GoalObserver,GameObservable {

	boolean reach = false;
    private ArrayList<GameObserver> gameObservers = new ArrayList <>();

	@Override
	public boolean checkCompleted(Dungeon dungeon) {
		// TODO Auto-generated method stub
		//check that exit coord is same as player coord
		if (reach) {
			System.out.println("exit goal completed");
			if (! dungeon.isComplexLevel())dungeon.win();			
			return true;
		}
		System.out.println("exit goal not completed");

		return false;
	}
	
	public void reachExit(boolean b) {
		reach = b;
	}
	
	@Override
	public void update(int i, Entity e, Dungeon d) {
		// TODO Auto-generated method stub
		if (i == 1) {
			reachExit(true);
			notifyGame(d);
		} else {
			reachExit(false);
		}
		checkCompleted(d);
		
	}

	@Override
	public boolean hasEnemyGoal(Enemy enemy) {
		return false;
	}

	@Override
	public boolean hasExitGoal(Player p) {
		p.register(this);
		return true;
	}

	@Override
	public boolean hasSwitchGoal(Dungeon d) {
		return false;
	}

	@Override
	public boolean hasTreasureGoal(Inventory i) {
		return false;
	}


	@Override
	public void register(GameObserver o) {
		gameObservers.add(o);
	}

	@Override
	public void unregister(GameObserver o) {
		int observerIndex = gameObservers.indexOf(o);
		gameObservers.remove(observerIndex);
	}

	@Override
	public void notifyGame(Dungeon d) {
		for(GameObserver o: gameObservers){
			o.update(d);
		}
	}

}