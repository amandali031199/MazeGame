package unsw.dungeon.Goals;
import java.io.IOException;
import java.util.ArrayList;

import unsw.dungeon.Observer.GameObservable;
import unsw.dungeon.Observer.GameObserver;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.*;

public class ComplexGoal implements GoalInterface,GameObserver,GameObservable {
	private String type;
	private ArrayList<GoalInterface> goals;
    private ArrayList<GameObserver> gameObservers = new ArrayList <>();
    
    /**
     * define if or / and relationship for goals
     * @param string
     */
	public ComplexGoal(String type) {
		this.goals = new ArrayList<GoalInterface>();
		this.type = type;
	}
	
	@Override
	public boolean checkCompleted(Dungeon dungeon)  {
		boolean result = false;
		if (type.equals("and")){
			result = true;
			for (GoalInterface g:goals) {
				if (g.checkCompleted(dungeon) == false) {
					result = false;
				}
			}
		} else { //type is or
			for (GoalInterface g:goals) {
				if (g.checkCompleted(dungeon) == true) {
					result = true;
				}
			}
			
		}
		if (result) dungeon.win();

		return result;
	}
	
	 public void addGoal(GoalInterface goal) {
        // set the change point
        this.goals.add(goal);
        ((GameObservable) goal).register(this);
	 }
	 
	 @Override
	public boolean hasEnemyGoal(Enemy e) {
		for (GoalInterface g: goals) {
			if (g instanceof EnemiesGoal) {
				e.register((GoalObserver) g);
				return true;
			}else if (g.hasEnemyGoal(e)) {
				return true;
			}
		 }
		 return false;
	}
	@Override
	public boolean hasExitGoal(Player p) {
		for (GoalInterface g: goals) {
			if (g instanceof ExitGoal) {
				p.register((GoalObserver)g);
				return true;
			} else if (g.hasExitGoal(p)) {
				return true;
			}
		 }
		 return false;
	}
	@Override
	public boolean hasSwitchGoal(Dungeon dungeon) {
		for (GoalInterface g: goals) {
			if (g instanceof SwitchGoal) {
				dungeon.register((GoalObserver) g);
				return true;
			} else if (g.hasSwitchGoal(dungeon)) {
				return true;
			}
		}
		return false;
	}
	@Override
	public boolean hasTreasureGoal(Inventory i) {
		for (GoalInterface g: goals) {
			if (g instanceof TreasureGoal) {
				i.register((GoalObserver) g);
				return true;
			} else if (g.hasTreasureGoal(i)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void update(Dungeon d) {
		checkCompleted(d);
	}

	@Override
	public void register(GameObserver o) {
		// TODO Auto-generated method stub
		gameObservers.add(o);
	}

	@Override
	public void unregister(GameObserver o) {
		// TODO Auto-generated method stub
		int observerIndex = gameObservers.indexOf(o);
		gameObservers.remove(observerIndex);
	}

	@Override
	public void notifyGame(Dungeon d) {
		// TODO Auto-generated method stub
		for(GameObserver o: gameObservers){
			o.update(d);
		}
	}
	

}