package unsw.dungeon.Goals;

import java.io.IOException;
import java.util.ArrayList;

import unsw.dungeon.Observer.GameObservable;
import unsw.dungeon.Observer.GameObserver;
import unsw.dungeon.Observer.GoalObserver;
import unsw.dungeon.*;

public class EnemiesGoal implements GoalInterface,GoalObserver,GameObservable {

    private int killedEnemies = 0;
    private ArrayList<GameObserver> gameObservers = new ArrayList <>();

	@Override
	public boolean checkCompleted(Dungeon dungeon) {
		// TODO Auto-generated method stub
		//check that all boulders in dungeon have the hasBoulder state
		if (killedEnemies == dungeon.noOfEnemies()) {
			System.out.println("enemy goal completed !!");
			if (! dungeon.isComplexLevel()) dungeon.win();
			return true;
		}
		System.out.println("enemy goal not completed");
		return false;
	}
	
	public void setEnemieskilled(int e) {
		killedEnemies = killedEnemies + e;
	}

	@Override
	public void update(int i,Entity e, Dungeon d) {
		// TODO Auto-generated method stub
		if (e instanceof Enemy) {
			setEnemieskilled(i);
			checkCompleted(d);
			notifyGame(d);
		}
	}

	@Override
	public boolean hasEnemyGoal(Enemy e) {
		// TODO Auto-generated method stub
		e.register(this);
		return true;
	}

	@Override
	public boolean hasExitGoal(Player p) {
		return false;
	}

	@Override
	public boolean hasSwitchGoal(Dungeon d) {
		return false;
	}

	@Override
	public boolean hasTreasureGoal(Inventory i) {
		return false;
	}

	@Override
	public void register(GameObserver o) {
		// TODO Auto-generated method stub
		gameObservers.add(o);
	}

	@Override
	public void unregister(GameObserver o) {
		// TODO Auto-generated method stub
		int observerIndex = gameObservers.indexOf(o);
		gameObservers.remove(observerIndex);
	}

	@Override
	public void notifyGame(Dungeon d) {
		// TODO Auto-generated method stub
		for(GameObserver o: gameObservers){
			o.update(d);
		}
	}

	

}