package unsw.dungeon;


import java.util.ArrayList;
import java.util.TimerTask;
import javafx.util.Duration;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import unsw.dungeon.Observer.EnemyObservable;
import unsw.dungeon.Observer.EnemyObserver;

public class TimeLimit extends TimerTask implements EnemyObservable{
	private Inventory inventory;
	private Potion potion;
	private Long period;    
	private ArrayList<EnemyObserver> enemyObservers;
	private Dungeon dungeon;

    public TimeLimit(Inventory inventory, Entity e, long period, Dungeon dungeon) {
    	this.inventory = inventory;
    	this.potion = (Potion) e;
    	this.period = period;
        this.enemyObservers = new ArrayList<>();
        this.dungeon = dungeon;
    }
    
	public void run() {
		
		while(true) {
			try {
				Thread.sleep(period);
			} catch (Exception e){
				e.printStackTrace();
			}
			// remove potion from inventory
		    inventory.removeEntity(potion);
			break;
		}
		notifyObserver(false); 
    }
	 @Override
		public void register(EnemyObserver o) {
			 enemyObservers.add(o);
		}

		@Override
		public void unregister(EnemyObserver o) {
			int observerIndex = enemyObservers.indexOf(o);
			enemyObservers.remove(observerIndex);

		}

		@Override
		public void notifyObserver(boolean b) {
			// TODO Auto-generated method stub
			if (inventory.numPotions() == null) {
				dungeon.removeGlow();
				for(EnemyObserver o: enemyObservers){
					o.changemoving(b);
				}
			}
		}


		@Override
		public void notifyObserver(int x, int y) {
			// TODO Auto-generated method stub
			
		}
}
  

  
  