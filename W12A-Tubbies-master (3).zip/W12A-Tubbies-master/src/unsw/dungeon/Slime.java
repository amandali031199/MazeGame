package unsw.dungeon;

public class Slime extends Entity {

    public Slime(int x, int y) {
        super(x, y);
    }

}

		