package unsw.dungeon.State;

import unsw.dungeon.Dungeon;

public interface EntityState {
	void change(Dungeon dungeon);
	void trigger(Dungeon dungeon);
	void untrigger(Dungeon dungeon);
}
