package unsw.dungeon.State;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

/**
 * state to keep track if entity is picked up
 * @author yinhuey
 *
 */
public class Collected implements EntityState {
	Entity entity;
	
	public Collected(Entity newentity) {
    	entity = newentity;
	    
	}
	/**
	 * add entity back to dungeon
	 */
	public void change(Dungeon dungeon) {
		dungeon.addEntity(entity);
	}

	@Override
	public void trigger(Dungeon dungeon) {
		
	}
	@Override
	public void untrigger(Dungeon dungeon) {
		
	}

}
