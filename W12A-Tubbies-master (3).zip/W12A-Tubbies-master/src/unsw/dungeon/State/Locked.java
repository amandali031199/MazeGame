package unsw.dungeon.State;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

public class Locked implements EntityState {
	Entity entity;
	
	public Locked(Entity newentity) {
    	entity = newentity;
	    
	}
	public void change(Dungeon dungeon) {
		//change image 
	}

	@Override
	public void trigger(Dungeon dungeon) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void untrigger(Dungeon dungeon) {
		// TODO Auto-generated method stub
		
	}

}
