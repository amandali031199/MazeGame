package unsw.dungeon.State;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

public class Unlocked implements EntityState {
	Entity entity;
	
	public Unlocked(Entity newentity) {
    	entity = newentity;	    
	}
	
	public void change(Dungeon dungeon) {
	}

	@Override
	public void trigger(Dungeon dungeon) {
		
	}
	@Override
	public void untrigger(Dungeon dungeon) {
		
	}

}
