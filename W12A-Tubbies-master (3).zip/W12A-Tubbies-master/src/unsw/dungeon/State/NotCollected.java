package unsw.dungeon.State;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

/**
 * state to keep track if entity is picked up
 * @author yinhuey
 *
 */
public class NotCollected implements EntityState {
	Entity entity;
	
	public NotCollected(Entity newentity) {
    	entity = newentity;
	    
	}

	public void change(Dungeon dungeon) {
		//make picture disappear
		dungeon.removeEntity(entity);		
	}
	@Override
	public void trigger(Dungeon dungeon) {		
	}
	
	@Override
	public void untrigger(Dungeon dungeon) {
		// TODO Auto-generated method stub
		

	}
}
