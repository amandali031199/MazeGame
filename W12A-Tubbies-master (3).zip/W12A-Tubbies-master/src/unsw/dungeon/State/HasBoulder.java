package unsw.dungeon.State;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

/**
 * state to keep track if switch has boulder on it 
 * aka if switch is triggered
 * @author yinhuey
 *
 */
public class HasBoulder implements EntityState{
	Entity entity;
	
	public HasBoulder(Entity newEntity) {
    	entity = newEntity;
	    
	}
	/** 
	 * increase and record triggered switches by 1
	 */
	public void trigger(Dungeon dungeon) {
		dungeon.setTriggeredSwitches(1,entity);
	}
	/** 
	 * decrease and record triggered switches by 1
	 */
	public void untrigger(Dungeon dungeon) {
		//dungeon.setTriggeredSwitches(-1,entity);
	}
	@Override
	public void change(Dungeon dungeon) {
		// TODO Auto-generated method stub
		
	}
}
