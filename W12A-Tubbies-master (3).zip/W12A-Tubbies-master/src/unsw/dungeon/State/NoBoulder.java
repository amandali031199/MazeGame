package unsw.dungeon.State;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Entity;

/**
 * state to keep track if switch has boulder on it 
 * aka if switch is triggered
 * @author yinhuey
 *
 */
public class NoBoulder implements EntityState{
	Entity entity;
	
	public NoBoulder(Entity newEntity) {
    	entity = newEntity;
	    
	}
	/** 
	 * increase and record triggered switches by 1
	 */
	public void trigger(Dungeon dungeon) {
		dungeon.setTriggeredSwitches(1,entity);
	}
	
	/** 
	 * decrease and record triggered switches by 1
	 */
	public void untrigger(Dungeon dungeon) {
		dungeon.setTriggeredSwitches(-1,entity);
	}
	@Override
	public void change(Dungeon dungeon) {
		
	}
}
