package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.Boulder;
import unsw.dungeon.Dungeon;
import unsw.dungeon.FloorSwitch;
import unsw.dungeon.Level;
import unsw.dungeon.Player;
import unsw.dungeon.Goals.SwitchGoal;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.HasBoulder;
import unsw.dungeon.State.NoBoulder;

class SwitchGoalTest {

	@Test
	void test() {
		int width = 30;
        int height = 30;

        Dungeon dungeon = new Dungeon(width, height);
        SwitchGoal x = new SwitchGoal();
        Level level = new Level(dungeon,x,false);
        dungeon.setLevel(level);
        
        // check if switch goal done when all boulders on switches
		Player p = new Player(dungeon,0,0);
		FloorSwitch f = new FloorSwitch(dungeon,2,0);
		FloorSwitch f1 = new FloorSwitch(dungeon,1,2);
		Boulder b = new Boulder(dungeon,1,0);
		Boulder b1 = new Boulder(dungeon,1,1);

		dungeon.addEntity(b);
		dungeon.addEntity(b1);
		dungeon.addEntity(f);
		dungeon.addEntity(f1);
		dungeon.recordEntity(f);
		dungeon.recordEntity(f1);
		dungeon.setPlayer(p);

        dungeon.initObservers();

		EntityState e = f.getEntityState() ;
		assert(e instanceof NoBoulder);
		EntityState e2 = f1.getEntityState() ;
		assert(e2 instanceof NoBoulder);
		
		// switch goal not done
		int oldx = b.getX();
		int oldy = b.getY();
		p.moveRight();
		f.update(b.getX(), b.getY(), oldx, oldy);
		EntityState e3 = f.getEntityState() ;
		assert(e3 instanceof HasBoulder);
		assert(x.checkCompleted(dungeon) == false);
		oldx = b.getX();
		oldy = b.getY();
		p.moveDown();
		assertEquals(p.getX(),1);
		assertEquals(p.getY(),1);
		assertEquals(b1.getX(),1);
		assertEquals(b1.getY(),2);
		
		// switch goal done

		f1.update(b1.getX(), b1.getY(), oldx, oldy);
		EntityState e4 = f1.getEntityState() ;
		assert(e4 instanceof HasBoulder);
		
		assert(x.checkCompleted(dungeon));

	}

}
