package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.Boulder;
import unsw.dungeon.Dungeon;
import unsw.dungeon.Enemy;
import unsw.dungeon.FloorSwitch;
import unsw.dungeon.Level;
import unsw.dungeon.Player;
import unsw.dungeon.Sword;
import unsw.dungeon.Treasure;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.EnemiesGoal;
import unsw.dungeon.Goals.SwitchGoal;
import unsw.dungeon.Goals.TreasureGoal;

class ComplexGoalTest2 {

	@Test
	void test() {
		int width = 30;
        int height = 30;
        // goal: enemies or (switch or treasure)
        Dungeon dungeon = new Dungeon(width, height);
        SwitchGoal s = new SwitchGoal();
        EnemiesGoal eg = new EnemiesGoal();
        TreasureGoal t = new TreasureGoal();
        ComplexGoal c = new ComplexGoal("or");
        c.addGoal(t);
        c.addGoal(s);
        ComplexGoal c2 = new ComplexGoal("or");
        c2.addGoal(c);
        c2.addGoal(eg);
        Level level = new Level(dungeon,c2,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		FloorSwitch f = new FloorSwitch(dungeon,2,2);
		Boulder b = new Boulder(dungeon,1,2);
		Enemy enemy = new Enemy(dungeon,2,0,p);
		Treasure treasure = new Treasure(dungeon,0,1);
		Sword sword = new Sword(dungeon,1,0);
		
		dungeon.addEntity(b);
		dungeon.addEntity(f);
		dungeon.addEntity(treasure);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);

		dungeon.recordEntity(b);
		dungeon.recordEntity(f);
		dungeon.recordEntity(treasure);
		dungeon.recordEntity(enemy);
		dungeon.recordEntity(sword);
		dungeon.setPlayer(p);
        dungeon.initObservers();
        
        // complete treasure goal, done level
        p.moveDown();
        p.pickUp();
        assert(t.checkCompleted(dungeon));
        assert(c.checkCompleted(dungeon));
        assert(c2.checkCompleted(dungeon));
       

	}
	
	@Test
	void test2() {
		int width = 30;
        int height = 30;
        // goal: enemies or (switch or treasure)
        Dungeon dungeon = new Dungeon(width, height);
        SwitchGoal s = new SwitchGoal();
        EnemiesGoal eg = new EnemiesGoal();
        TreasureGoal t = new TreasureGoal();
        ComplexGoal c = new ComplexGoal("or");
        c.addGoal(t);
        c.addGoal(s);
        ComplexGoal c2 = new ComplexGoal("or");
        c2.addGoal(c);
        c2.addGoal(eg);
        Level level = new Level(dungeon,c2,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		FloorSwitch f = new FloorSwitch(dungeon,2,2);
		Boulder b = new Boulder(dungeon,1,2);
		Enemy enemy = new Enemy(dungeon,2,0,p);
		Treasure treasure = new Treasure(dungeon,0,1);
		Sword sword = new Sword(dungeon,1,0);
		
		dungeon.addEntity(b);
		dungeon.addEntity(f);
		dungeon.addEntity(treasure);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);

		dungeon.recordEntity(b);
		dungeon.recordEntity(f);
		dungeon.recordEntity(treasure);
		dungeon.recordEntity(enemy);
		dungeon.recordEntity(sword);
		dungeon.setPlayer(p);
        dungeon.initObservers();
        
        // complete enemy goal
        p.moveRight();
        p.pickUp();
        p.moveRight();
        assert(eg.checkCompleted(dungeon));
        assert(!c.checkCompleted(dungeon));
        assert(c2.checkCompleted(dungeon));
	}
	
	@Test
	void test3() {
		int width = 30;
        int height = 30;
        // goal: enemies or (switch or treasure)
        Dungeon dungeon = new Dungeon(width, height);
        SwitchGoal s = new SwitchGoal();
        EnemiesGoal eg = new EnemiesGoal();
        TreasureGoal t = new TreasureGoal();
        ComplexGoal c = new ComplexGoal("or");
        c.addGoal(t);
        c.addGoal(s);
        ComplexGoal c2 = new ComplexGoal("or");
        c2.addGoal(c);
        c2.addGoal(eg);
        Level level = new Level(dungeon,c2,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		FloorSwitch f = new FloorSwitch(dungeon,2,2);
		Boulder b = new Boulder(dungeon,1,2);
		Enemy enemy = new Enemy(dungeon,2,0,p);
		Treasure treasure = new Treasure(dungeon,0,1);
		Sword sword = new Sword(dungeon,1,0);
		
		dungeon.addEntity(b);
		dungeon.addEntity(f);
		dungeon.addEntity(treasure);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);

		dungeon.recordEntity(b);
		dungeon.recordEntity(f);
		dungeon.recordEntity(treasure);
		dungeon.recordEntity(enemy);
		dungeon.recordEntity(sword);
		dungeon.setPlayer(p);
        dungeon.initObservers();
        
        // complete switch goal, done level
        p.moveDown();
        p.moveDown();
        p.moveRight();
        assert(s.checkCompleted(dungeon));
        assert(c.checkCompleted(dungeon));
        assert(c2.checkCompleted(dungeon));
       

	}
	
}
