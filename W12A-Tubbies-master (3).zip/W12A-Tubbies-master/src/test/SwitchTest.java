package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.Boulder;
import unsw.dungeon.Dungeon;
import unsw.dungeon.FloorSwitch;
import unsw.dungeon.Level;
import unsw.dungeon.Player;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.ExitGoal;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.HasBoulder;
import unsw.dungeon.State.NoBoulder;

class SwitchTest {

	@Test
	void test() {
		int width = 30;
        int height = 30;

        Dungeon dungeon = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        ComplexGoal c = new ComplexGoal("and");
        c.addGoal(x);
        Level level = new Level(dungeon,c,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		FloorSwitch f = new FloorSwitch(dungeon,3,0);
		Boulder b = new Boulder(dungeon,1,0);
		dungeon.addEntity(b);
		dungeon.addEntity(f);
		EntityState e = f.getEntityState() ;
		assert(e instanceof NoBoulder);
		
		// push boulder to floor switch
		// floor switch changes state from noboulder to hasboulder, triggered
		p.moveRight();
		int oldx = b.getX();
		int oldy = b.getY();
		p.moveRight();
		assertEquals(p.getX(),2);
		assertEquals(p.getY(),0);
		assertEquals(b.getX(),3);
		assertEquals(b.getY(),0);
		assertEquals(f.getX(),3);
		assertEquals(f.getY(),0);
		EntityState e2 = f.getEntityState() ;
		assert(e2 instanceof NoBoulder);
		f.update(b.getX(), b.getY(), oldx, oldy);
		EntityState e3 = f.getEntityState() ;
		assert(e3 instanceof HasBoulder);
		
		// floor switch untrigger when boulder moves away
		// player can walk on switch
		oldx = b.getX();
		oldy = b.getY();
		p.moveRight();
		f.update(b.getX(), b.getY(), oldx, oldy);
		EntityState e4 = f.getEntityState() ;
		assert(e4 instanceof NoBoulder);
		assertEquals(f.getX(),p.getX());
		assertEquals(f.getY(),p.getY());

	}

}
