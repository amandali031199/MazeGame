package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import unsw.dungeon.*;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.EnemiesGoal;
import unsw.dungeon.Goals.ExitGoal;

import java.util.concurrent.Callable;

class PotionTest {
	@Test
	void TestPotionEnd() throws FileNotFoundException {
			int width = 30;
	        int height = 30;

	        Dungeon d = new Dungeon(width, height);
	        ExitGoal x = new ExitGoal();
	        EnemiesGoal e = new EnemiesGoal();
	        ComplexGoal c = new ComplexGoal("and");
	        c.addGoal(x);
	        c.addGoal(e);
	        Level level = new Level(d,c,true);
	        d.setLevel(level);
	        Player player = new Player(d, 0,0);
	        d.setPlayer(player);
	        Potion p = new Potion(d,0,0);
	        Enemy e1 = new Enemy(d,3,0, player);
	        d.recordEntity(p);
	        d.recordEntity(e1);

	        d.addEntity(e1);
	        d.addEntity(p);
			d.initObservers();
	        d.addEntity(player);
			Inventory playersInventory = player.getInventory();
			//add mock potion with 0 seconds countdown
			playersInventory.addPotion(p, 0);
			//check enemy walks to us after potion is finished
			player.moveRight();
			assert(e1.getX() == 2);
			assert(e1.getY() == 0);
			//check player dies 
			player.moveRight();
			assert(!d.containsEntity(player));
	}
}