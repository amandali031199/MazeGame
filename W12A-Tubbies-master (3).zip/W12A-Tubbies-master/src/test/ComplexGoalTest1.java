package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.Boulder;
import unsw.dungeon.Dungeon;
import unsw.dungeon.Exit;
import unsw.dungeon.FloorSwitch;
import unsw.dungeon.Level;
import unsw.dungeon.Player;
import unsw.dungeon.Treasure;
import unsw.dungeon.Frontend.DungeonController;
import unsw.dungeon.Frontend.DungeonControllerLoader;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.ExitGoal;
import unsw.dungeon.Goals.SwitchGoal;
import unsw.dungeon.Goals.TreasureGoal;
import unsw.dungeon.State.EntityState;
import unsw.dungeon.State.HasBoulder;
import unsw.dungeon.State.NoBoulder;

class ComplexGoalTest1 {

	@Test
	void test() {
		int width = 30;
        int height = 30;
        
        // goal : (exit and switch) and treasure
        Dungeon dungeon = new Dungeon(width, height);
        SwitchGoal s = new SwitchGoal();
        ExitGoal x = new ExitGoal();
        TreasureGoal t = new TreasureGoal();
        ComplexGoal c = new ComplexGoal("and");
        c.addGoal(x);
        c.addGoal(s);
        ComplexGoal c2 = new ComplexGoal("and");
        c2.addGoal(c);
        c2.addGoal(t);
        Level level = new Level(dungeon,c2,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		FloorSwitch f = new FloorSwitch(dungeon,2,0);
		Boulder b = new Boulder(dungeon,1,0);
		Exit exit = new Exit(dungeon,2,1);
		Treasure treasure = new Treasure(dungeon,1,1);

		dungeon.addEntity(b);
		dungeon.addEntity(f);
		dungeon.addEntity(treasure);
		dungeon.addEntity(exit);
		dungeon.recordEntity(b);
		dungeon.recordEntity(f);
		dungeon.recordEntity(treasure);
		dungeon.recordEntity(exit);
		dungeon.setPlayer(p);
        dungeon.initObservers();
        // do switch goal
        EntityState e2 = f.getEntityState() ;
		assert(e2 instanceof NoBoulder);
        p.moveRight();
        EntityState e4 = f.getEntityState() ;
		assert(e4 instanceof HasBoulder);
        assert(s.checkCompleted(dungeon));
        assert(!c2.checkCompleted(dungeon)); 
        // go to exit
        p.moveDown();
        p.moveRight();
        assert(c.checkCompleted(dungeon)); 
        assert(x.checkCompleted(dungeon));
        assert(!c2.checkCompleted(dungeon)); 
        // do treasure goal
        p.moveLeft();
        p.pickUp();
        assert(t.checkCompleted(dungeon));
        assert(!c.checkCompleted(dungeon)); 
        assert(!c2.checkCompleted(dungeon)); 
        
        // move back to exit
        // complete level
        p.moveRight();
        assert(c.checkCompleted(dungeon)); 
        assert(c2.checkCompleted(dungeon)); 

	}

}
