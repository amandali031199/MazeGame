package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import unsw.dungeon.*;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.EnemiesGoal;
import unsw.dungeon.Goals.ExitGoal;

import java.util.concurrent.Callable;

class EnemyTest {
	
	@Test
	void testEnemy() throws FileNotFoundException {
		int width = 30;
        int height = 30;

        Dungeon d = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        EnemiesGoal e = new EnemiesGoal();
        ComplexGoal c = new ComplexGoal("and");
        c.addGoal(x);
        c.addGoal(e);
        Level level = new Level(d,c,true);
        d.setLevel(level);
        Player player = new Player(d, 4,0);
        Enemy p = new Enemy(d, 0, 0, player);
        d.setPlayer(player);
        Wall wall = new Wall(3,2);
        Boulder b = new Boulder(d, 2,2);
        Door door = new Door(d,1,2, 0);
        FloorSwitch f = new FloorSwitch(d, 0, 2);
        Portal portal = new Portal(d, 3, 3, 0);
        Treasure t = new Treasure(d, 3, 4);
        Exit exit = new Exit(d, 1,3);
        d.recordEntity(exit);
        d.recordEntity(t);
        d.recordEntity(portal);
        d.recordEntity(f);
        d.recordEntity(door);
        d.recordEntity(b);
        d.recordEntity(wall);

        d.addEntity(exit);
        d.addEntity(t);
        d.addEntity(portal);
        d.addEntity(f);
        d.addEntity(door);
        d.addEntity(b);
        d.addEntity(wall);
        d.addEntity(p);
		//cant walk through boulder wall  or locked door
        assert(!d.EnemyCanMove(1, 2));
        assert(!d.EnemyCanMove(2, 2));
        assert(!d.EnemyCanMove(3, 2));

		//can walk over floor switch
        assert(d.EnemyCanMove(0, 2));
        
		//when player move enemy moves closer
        player.moveRight();
        assert(player.getX() == 5);
        assert(p.getX() == 1);
        player.moveLeft();
        assert(player.getX() == 4);
        assert(p.getX() == 2);
		//player get killed without weapon
        //player.moveLeft();
        //player.moveLeft();
        assert(player.getX() == 4);
        assert(!d.containsEntity(player));
	}
	
	@Test
	void testSword() throws FileNotFoundException {
		int width = 30;
        int height = 30;

        Dungeon d = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        EnemiesGoal e = new EnemiesGoal();
        ComplexGoal c = new ComplexGoal("and");
        c.addGoal(x);
        c.addGoal(e);
        Level level = new Level(d,c,true);
        d.setLevel(level);
        Player player = new Player(d, 3,0);

        d.setPlayer(player);
        Sword s = new Sword(d, 2, 0);
        Sword s1 = new Sword(d, 0, 0);
        Exit exit = new Exit(d, 1,3);
        d.recordEntity(exit);
        d.recordEntity(s);
        d.recordEntity(s1);

        d.addEntity(exit);
        d.addEntity(s);
        d.addEntity(s1);
		d.initObservers();
        d.addEntity(player);
		Inventory playersInventory = player.getInventory();
		//pick up sword
        player.moveLeft();
        assert(player.getY() == s.getY());
        player.pickUp(); //at right place
		assert(playersInventory.containsEntity(s));
		assert(!d.containsEntity(s));
		assert(s.GetState() == s.GetCollectedState());
		//kill enemy 
        player.moveLeft();
        assert(player.getX() == 1);
        assert(player.getY() == 0);
        Enemy e1 = new Enemy(d,1,0, player);
        d.addEntity(e1);
        d.recordEntity(e1);
		assert(d.containsEntity(e1));
		/*player.moveLeft();
		assert(!d.containsEntity(e1));

		//check sword is still in inventory
		assert(playersInventory.containsEntity(s));
		//pick up another sword doesnt work
		player.moveLeft();
		player.pickUp(); //here i killed another

		assert(!playersInventory.containsEntity(s1));
		assert(playersInventory.containsEntity(s));


		//kill 4 more enemies
        Enemy e2 = new Enemy(d, 0, 1, player);
        d.recordEntity(e2);
        d.addEntity(e2);
        d.initObservers();
        player.moveDown();
		assert(!d.containsEntity(e2));

        Enemy e3 = new Enemy(d, 0, 2, player);
        d.recordEntity(e3);
        d.addEntity(e3);
        d.initObservers();
        player.moveDown();
		assert(!d.containsEntity(e3));
		
        Enemy e4 = new Enemy(d, 0, 3, player);
        d.recordEntity(e4);
        d.addEntity(e4);
        d.initObservers();
        player.moveDown();
		assert(!d.containsEntity(e4));
		
        Enemy e5 = new Enemy(d, 0, 4, player);
        d.recordEntity(e5);
        d.addEntity(e5);
        d.initObservers();
        player.moveDown();
		assert(!d.containsEntity(e5));        
		//check sword disappears
		assert(!playersInventory.containsEntity(s));
		*/
		
	}
	
	@Test
	void testPotion() throws FileNotFoundException, InterruptedException {
		int width = 30;
        int height = 30;

        Dungeon d = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        EnemiesGoal e = new EnemiesGoal();
        ComplexGoal c = new ComplexGoal("or");
        c.addGoal(x);
        c.addGoal(e);
        Level level = new Level(d,c,true);
        d.setLevel(level);
        Player player = new Player(d, 3,0);


        d.setPlayer(player);
        Potion p = new Potion(d, 2, 0);
        Potion p1 = new Potion(d, 0, 0);
        Exit exit = new Exit(d, 0,1);
        d.recordEntity(exit);
        d.recordEntity(p);
        d.recordEntity(p1);



        d.addEntity(exit);
        d.addEntity(p);
        d.addEntity(p1);
		d.initObservers();
        d.addEntity(player);
		Inventory playersInventory = player.getInventory();
		//pick up potion 
		player.moveLeft();
		player.pickUp();
		assert(player.getX() == p.getX());
		assert(playersInventory.containsEntity(p));
		assert(!d.containsEntity(p));
		assert(p.GetState() == p.GetCollectedState());
		//check enemy walks away 
		player.moveRight();
		//System.out.println(player.getX());
		//System.out.println(player.getY());
		player.moveLeft();
		player.moveLeft();
		assert(playersInventory.containsEntity(p));
        Enemy e2 = new Enemy(d, 2, 0, player);
        d.addEntity(e2);
        d.recordEntity(e2);
        d.initObservers();
        //kill enemy
		/*player.notifyKill(e2);
		//pick up another
		player.moveLeft();
		//System.out.println(player.getX());
		//System.out.println(player.getY());
		player.pickUp();
		Enemy e3 = new Enemy(d, 0, 0, player);
        d.addEntity(e3);
        d.recordEntity(e3);
        d.initObservers();
        //kill enemy
		player.notifyKill(e3);
		//check goals: exit or enemies; (exit complete end not)
	    assert(!e.checkCompleted(d));
	    assert(!x.checkCompleted(d));
	    assert(!c.checkCompleted(d));
	    
		//walk to exit (only complete one goal);
	    player.moveDown();
	    assert(player.getX() == 0);
	    assert(player.getY() == 1);
	    
	    assert(!e.checkCompleted(d));
	    assert(x.checkCompleted(d));
	    assert(c.checkCompleted(d));
	    */
	} 

}