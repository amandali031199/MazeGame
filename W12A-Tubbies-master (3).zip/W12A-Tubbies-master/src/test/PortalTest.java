package test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.jupiter.api.Test;

import unsw.dungeon.*;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.ExitGoal;

class PortalTest {

	@Test
	void testEnterPortal() throws FileNotFoundException {

        int width = 30;
        int height = 30;

        Dungeon dungeon = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        ComplexGoal c = new ComplexGoal("and");
        c.addGoal(x);
        Level level = new Level(dungeon,c,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		Portal portal1 = new Portal(dungeon,3,1,1);
		dungeon.addEntity(portal1);
		assertEquals(dungeon.isPortal(3, 1),1);
		
		Portal portal2 = new Portal(dungeon,9,4,1);
		dungeon.addEntity(portal2);
		Portal p2 = (Portal) dungeon.getAnotherPortal(1, 3, 2);
		assertEquals(dungeon.isPortal(9, 4),1);

		assertEquals(p2.getId(),portal2.getId());
		assertEquals(p2.getX(),portal2.getX());
		assertEquals(p2.getY(),portal2.getY());
		
		p.moveRight();
		p.moveRight();
		p.moveRight();
		// player enter the portal
		assert(p.EnteredPortal(1,p.x(), p.y(), p.getX(), p.getY()-1));
		// player teleported to another portal
		assertEquals(p.getX(),9);
		assertEquals(p.getY(),4);


	}

}
