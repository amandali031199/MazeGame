package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.Boulder;
import unsw.dungeon.Dungeon;
import unsw.dungeon.Level;
import unsw.dungeon.Player;
import unsw.dungeon.Wall;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.ExitGoal;

class BoulderTest {

	@Test
	void test() {
		int width = 30;
        int height = 30;

        Dungeon dungeon = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        ComplexGoal c = new ComplexGoal("and");
        c.addGoal(x);
        Level level = new Level(dungeon,c,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		Boulder b = new Boulder(dungeon,1,1);
		Wall w1 = new Wall(2,1);
		dungeon.addEntity(w1);
		dungeon.addEntity(b);
		
		p.moveDown();
		assertEquals(p.getX(),0);
		assertEquals(p.getY(),1);
		
		// cant push the boulder to the wall
		// still stay at same position
		p.moveRight();
		assertEquals(p.getX(),0);
		assertEquals(p.getY(),1);
		p.moveUp();
		assertEquals(p.getX(),0);
		assertEquals(p.getY(),0);
		p.moveRight();

		// player pushes the boulder
		p.moveDown();
		assertEquals(p.getX(),1);
		assertEquals(p.getY(),1);
		assertEquals(b.getX(),1);
		assertEquals(b.getY(),2);
		
		// boulder hits corner wall
		Wall w2 = new Wall(2,2);
		dungeon.addEntity(w2);
		Wall w3 = new Wall(1,3);
		dungeon.addEntity(w3);
		Wall w4 = new Wall(2,3);
		dungeon.addEntity(w4);
		
		p.moveDown();
		assertEquals(p.getX(),1);
		assertEquals(p.getY(),1);
		assertEquals(b.getX(),1);
		assertEquals(b.getY(),2);
		
	}

}
