package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import unsw.dungeon.Dungeon;
import unsw.dungeon.Enemy;
import unsw.dungeon.Exit;
import unsw.dungeon.Level;
import unsw.dungeon.Player;
import unsw.dungeon.Sword;
import unsw.dungeon.Treasure;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.EnemiesGoal;
import unsw.dungeon.Goals.ExitGoal;
import unsw.dungeon.Goals.TreasureGoal;

class ComplexGoalTest3 {
	@Test
	void test() {
		int width = 30;
        int height = 30;
        // goal: (treasure or exit) and enemies
        Dungeon dungeon = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        EnemiesGoal eg = new EnemiesGoal();
        TreasureGoal t = new TreasureGoal();
        ComplexGoal c = new ComplexGoal("or");
        c.addGoal(t);
        c.addGoal(x);
        ComplexGoal c2 = new ComplexGoal("and");
        c2.addGoal(c);
        c2.addGoal(eg);
        Level level = new Level(dungeon,c2,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		Exit exit = new Exit(dungeon,2,0);
		Enemy enemy = new Enemy(dungeon,1,1,p);
		Treasure treasure = new Treasure(dungeon,0,1);
		Sword sword = new Sword(dungeon,1,0);
		
		dungeon.addEntity(exit);
		dungeon.addEntity(treasure);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);

		dungeon.recordEntity(exit);
		dungeon.recordEntity(treasure);
		dungeon.recordEntity(enemy);
		dungeon.recordEntity(sword);
		dungeon.setPlayer(p);
        dungeon.initObservers();
        
        // complete treasure goal,not done w level
        p.moveDown();
        p.pickUp();
        assert(t.checkCompleted(dungeon));
        assert(c.checkCompleted(dungeon));
        assert(!c2.checkCompleted(dungeon));
        
        // kill enemy and pass level
        p.moveUp();
        p.moveRight();
        p.pickUp();
        p.moveDown();
        assert(eg.checkCompleted(dungeon));
        assert(c.checkCompleted(dungeon));
        assert(c2.checkCompleted(dungeon));
	}
	
	void test2() {
		int width = 30;
        int height = 30;
        // goal: (treasure or exit)  and enemies
        Dungeon dungeon = new Dungeon(width, height);
        ExitGoal x = new ExitGoal();
        EnemiesGoal eg = new EnemiesGoal();
        TreasureGoal t = new TreasureGoal();
        ComplexGoal c = new ComplexGoal("or");
        c.addGoal(t);
        c.addGoal(x);
        ComplexGoal c2 = new ComplexGoal("and");
        c2.addGoal(c);
        c2.addGoal(eg);
        Level level = new Level(dungeon,c2,true);
        dungeon.setLevel(level);
        
		Player p = new Player(dungeon,0,0);
		Exit exit = new Exit(dungeon,2,0);
		Enemy enemy = new Enemy(dungeon,1,1,p);
		Treasure treasure = new Treasure(dungeon,0,1);
		Sword sword = new Sword(dungeon,1,0);
		
		dungeon.addEntity(exit);
		dungeon.addEntity(treasure);
		dungeon.addEntity(enemy);
		dungeon.addEntity(sword);

		dungeon.recordEntity(exit);
		dungeon.recordEntity(treasure);
		dungeon.recordEntity(enemy);
		dungeon.recordEntity(sword);
		dungeon.setPlayer(p);
        dungeon.initObservers();
        
        // kill enemy, not done w level
        p.moveRight();
        p.pickUp();
        p.moveDown();
        assert(eg.checkCompleted(dungeon));
        assert(!c.checkCompleted(dungeon));
        assert(!c2.checkCompleted(dungeon));
        
        // go to exit, pass level
        p.moveRight();
        p.moveUp();
        assert(x.checkCompleted(dungeon));
        assert(c.checkCompleted(dungeon));
        assert(c2.checkCompleted(dungeon));
	}

}
