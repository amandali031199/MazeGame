package test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import unsw.dungeon.*;
import unsw.dungeon.Goals.ComplexGoal;
import unsw.dungeon.Goals.ExitGoal;
import unsw.dungeon.Goals.TreasureGoal;

class PickupTest {

	
	@Test
	void testTreasureKeyDoor() throws FileNotFoundException {
	    //DungeonControllerLoader dungeonLoader = new DungeonControllerLoader("advanced.json");
		//Dungeon d = new Dungeon(10,10, dungeonLoader)
		int width = 30;
	    int height = 30;

	    Dungeon d = new Dungeon(width, height);
	    ExitGoal x = new ExitGoal();
	    TreasureGoal g = new TreasureGoal();
	    ComplexGoal c = new ComplexGoal("and");
	    c.addGoal(x);
	    c.addGoal(g);
	    Level level = new Level(d,c,true);
	    d.setLevel(level);
		Player p = new Player(d, 0, 0);
		Treasure t = new Treasure(d, 1,0);
		Treasure t1 = new Treasure (d, 1, 1);
		Door door = new Door(d, 0, 1, 0);
		Key wrong = new Key(d, 1, 2, 1);
		Key right = new Key(d, 3, 0 , 0);
		Exit exit = new Exit(d, 1,3);
		d.recordEntity(exit);
		d.addEntity(exit);

		d.setPlayer(p);
		d.addEntity(p);
		d.addEntity(t);
		d.addEntity(t1);
		d.addEntity(door);
		d.addEntity(wrong);
		d.addEntity(right);
		
		d.recordEntity(p);
		d.recordEntity(t);
		d.recordEntity(t1);
		d.recordEntity(door);
		d.recordEntity(wrong);
		d.recordEntity(right);
		d.initObservers();
		Inventory playersInventory = p.getInventory();
		//check inventory is empty to being with
		assert(emptyInventory(playersInventory));
		
		//try to pick up treasure 		
		//not in the right square
		p.pickUp();
		assert(emptyInventory(playersInventory));

		p.moveRight();
		assert(p.getX() == 1);
		p.pickUp();
		//check inventory, dungeon, state
		assert(playersInventory.containsEntity(t));
		assert(!d.containsEntity(t));
		assert(t.GetState() == t.GetCollectedState());
		//pick up a second treasure, checks
		p.moveDown(); //1,1
		assert(p.getX() == 1);
		p.pickUp();
		//check inventory, dungeon, state
		assert(playersInventory.containsEntity(t1));
		assert(!d.containsEntity(t1));
		assert(t1.GetState() == t1.GetCollectedState());
		
		//try to walk through door (locked)
		//pick up wrong key
		p.moveDown();// 1,2
		p.pickUp();
		assert(playersInventory.containsEntity(wrong));
		assert(!d.containsEntity(wrong));
		assert(wrong.GetState()== wrong.GetCollectedState());
		//try door(locked)
		p.moveUp(); //1, 1
		assert(door.GetState() == door.GetLockedState());
		//pick up right key
		p.moveRight(); //2, 1
		p.moveRight(); //3, 1
		p.moveUp(); //3, 0
		p.pickUp();
		//check swapped 
		assert(playersInventory.containsEntity(right));
		assert(!playersInventory.containsEntity(wrong));
		assert(!d.containsEntity(right));
		assert(d.containsEntity(wrong));
		assert(right.GetState()== right.GetCollectedState());
		assert(wrong.GetState() == wrong.GetNotCollectedState());
		//try door opened
		p.moveDown(); //3,1
		p.moveLeft(); //2,1
		p.moveLeft(); //1,1
		assert(door.GetState() == door.GetUnlockedState());
		//key is used
		assert(!playersInventory.containsEntity(right));
		
		//try walk through wall
		Wall wall = new Wall(2, 1);
		d.addEntity(wall);
		d.recordEntity(wall);
		p.moveRight();
		assert(p.getX() == 1);
		assert(p.getY() == 1);
		//walk to exit
		p.moveRight();

		p.moveDown();
		p.moveDown();
		
		assert(p.getX() == 1);
		assert(p.getY() == 3);
		//goal reached exit and pick up all treasure
	    assert(g.checkCompleted(d));
	    assert(x.checkCompleted(d));
	    assert(c.checkCompleted(d));

		
	}
	
	boolean EntInInvent(Entity e, ArrayList<Entity> list) {
		return list.contains(e);
	}
	@ParameterizedTest
	@MethodSource(value = "playersInventory")
	 boolean emptyInventory(Inventory inventory){
		return inventory.isEmpty();
	}
	
}